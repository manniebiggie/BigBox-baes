-- ============================================================
-- bigbox_bridge | server/main.lua
-- Implementa o subconjunto mais usado da API do qb-core / qbx_core
-- em cima dos exports do bigbox.
-- ============================================================

local QBCore = { Functions = {}, Commands = {}, Shared = {} }

local function license(src)
    return GetPlayerIdentifierByType(src, 'license')
end

local function T(key)
    return exports.bigbox:Translate(key)
end

-- ---------------- Objeto jogador (formato QB) ----------------

local function makePlayer(src)
    src = tonumber(src)
    if not src then return nil end
    local d = exports.bigbox:GetPlayerData(src)
    if not d then return nil end

    local self = {
        PlayerData = BR.ToQBPlayerData(d, license(src)),
        Offline = false,
        Functions = {},
    }
    local F = self.Functions

    function F.UpdatePlayerData() end
    function F.SetPlayerData() end
    function F.Save() return exports.bigbox:Save(src) end
    function F.Logout() return exports.bigbox:Logout(src) end

    -- grade nil = menor cargo do emprego (não força o nível 0)
    function F.SetJob(job, grade) return exports.bigbox:SetJob(src, job, tonumber(grade)) end
    function F.SetGang(gang, grade) return exports.bigbox:SetGang(src, gang, tonumber(grade)) end
    function F.SetJobDuty(onDuty) return exports.bigbox:SetDuty(src, onDuty) end

    function F.AddMoney(mtype, amount, reason) return exports.bigbox:AddMoney(src, mtype, amount, reason) end
    function F.RemoveMoney(mtype, amount, reason) return exports.bigbox:RemoveMoney(src, mtype, amount, reason) end
    function F.SetMoney(mtype, amount) return exports.bigbox:SetMoney(src, mtype, amount) end
    function F.GetMoney(mtype) return exports.bigbox:GetMoney(src, mtype) end

    function F.AddItem(name, amount) return exports.bigbox:AddItem(src, name, amount or 1) end
    function F.RemoveItem(name, amount) return exports.bigbox:RemoveItem(src, name, amount or 1) end

    function F.GetItemByName(name)
        local data = exports.bigbox:GetPlayerData(src)
        for i, it in ipairs(data and data.inventory or {}) do
            if it.name == name then return BR.QBItem(it, i) end
        end
        return nil
    end

    function F.GetItemsByName(name)
        local out = {}
        local data = exports.bigbox:GetPlayerData(src)
        for i, it in ipairs(data and data.inventory or {}) do
            if it.name == name then out[#out + 1] = BR.QBItem(it, i) end
        end
        return out
    end

    function F.SetMetaData(key, value) return exports.bigbox:SetMetadata(src, key, value) end
    function F.GetMetaData(key) return exports.bigbox:GetMetadata(src, key) end

    function F.Notify(text, ntype, length)
        return exports.bigbox:Notify(src, text, BR.NotifyType(ntype), length)
    end

    return self
end

-- ---------------- QBCore.Functions ----------------

function QBCore.Functions.GetPlayer(src) return makePlayer(src) end

function QBCore.Functions.GetPlayerByCitizenId(cid)
    local src = exports.bigbox:GetSourceByCitizenId(cid)
    return src and makePlayer(src) or nil
end

function QBCore.Functions.GetPlayers() return exports.bigbox:GetAllSources() end

function QBCore.Functions.GetQBPlayers()
    local out = {}
    for _, src in ipairs(exports.bigbox:GetAllSources()) do out[src] = makePlayer(src) end
    return out
end

--- Quantos jogadores estão em serviço no emprego dado (usado por scripts de polícia/ambulância).
function QBCore.Functions.GetDutyCount(job)
    local count = 0
    for _, src in ipairs(exports.bigbox:GetAllSources()) do
        local d = exports.bigbox:GetPlayerData(src)
        if d and d.job and d.job.name == job and d.job.onduty then count = count + 1 end
    end
    return count
end

function QBCore.Functions.GetIdentifier(src, idtype)
    return GetPlayerIdentifierByType(src, idtype or 'license')
end

function QBCore.Functions.Notify(src, text, ntype, length)
    return exports.bigbox:Notify(src, text, BR.NotifyType(ntype), length)
end

function QBCore.Functions.HasItem(src, items, amount)
    amount = amount or 1
    if type(items) == 'string' then items = { items } end
    for _, name in pairs(items or {}) do
        if not exports.bigbox:HasItem(src, name, amount) then return false end
    end
    return true
end

--- CreateCallback(name, function(source, cb, ...) ... cb(resultado) end)
function QBCore.Functions.CreateCallback(name, cb)
    lib.callback.register(name, function(src, ...)
        local p = promise.new()
        cb(src, function(...) p:resolve(table.pack(...)) end, ...)
        local r = Citizen.Await(p)
        return table.unpack(r, 1, r.n)
    end)
end

--- CreateUseableItem(name, function(source, item) ... end)
function QBCore.Functions.CreateUseableItem(name, cb)
    exports.bigbox:RegisterUsable(name, function(src)
        cb(src, {
            name = name,
            amount = exports.bigbox:GetItemCount(src, name),
            label = name, slot = 1, info = {}, type = 'item',
        })
    end)
end

-- ---------------- QBCore.Commands ----------------

function QBCore.Commands.Add(name, help, args, argsRequired, cb, permission)
    RegisterCommand(name, function(src, cmdArgs, raw)
        if src ~= 0 and permission and permission ~= 'user' and not exports.bigbox:IsAdmin(src) then
            return exports.bigbox:Notify(src, T('no_permission'), 'error')
        end
        if argsRequired and #cmdArgs < #(args or {}) then
            return exports.bigbox:Notify(src, T('args_missing'), 'error')
        end
        cb(src, cmdArgs, raw)
    end, false)
end

-- ---------------- Shared ----------------
-- Uma única tabela, atualizada no lugar sempre que o registro do bigbox muda.
-- Assim scripts que guardaram QBCore.Shared.Items numa variável continuam atualizados.

local function rawRegistry()
    return exports.bigbox:GetItems(), exports.bigbox:GetJobs(), exports.bigbox:GetGangs()
end

local function refreshShared()
    local items, jobs, gangs = rawRegistry()
    BR.FillShared(QBCore.Shared, items, jobs, gangs)
    TriggerClientEvent('bigbox_bridge:client:sharedUpdated', -1, { items = items, jobs = jobs, gangs = gangs })
end

lib.callback.register('bigbox_bridge:getShared', function()
    local items, jobs, gangs = rawRegistry()
    return { items = items, jobs = jobs, gangs = gangs }
end)

-- O bigbox avisa sempre que itens/empregos/gangues são recarregados (inclusive edições do painel).
AddEventHandler('bigbox:server:registryReloaded', refreshShared)

-- Se a ponte subiu DEPOIS de o bigbox já estar pronto, o aviso acima já passou:
-- busca agora, tentando de novo enquanto o registro ainda estiver vazio.
CreateThread(function()
    for _ = 1, 60 do
        local ok, items = pcall(function() return exports.bigbox:GetItems() end)
        if ok and items and next(items) then
            refreshShared()
            return
        end
        Wait(1000)
    end
end)

-- ---------------- Exports ----------------

exports('GetCoreObject', function()
    return QBCore
end)

-- Subconjunto da API do qbx_core
exports('GetPlayer', function(src) return makePlayer(src) end)
exports('GetPlayerByCitizenId', function(cid) return QBCore.Functions.GetPlayerByCitizenId(cid) end)
exports('GetQBPlayers', function() return QBCore.Functions.GetQBPlayers() end)
exports('Notify', function(src, text, ntype, duration)
    return exports.bigbox:Notify(src, text, BR.NotifyType(ntype), duration)
end)
exports('GetJobs', function() return QBCore.Shared.Jobs end)
exports('GetGangs', function() return QBCore.Shared.Gangs end)

-- ---------------- Eventos: bigbox -> QBCore ----------------

AddEventHandler('bigbox:server:playerLoaded', function(src)
    TriggerEvent('QBCore:Server:PlayerLoaded', makePlayer(src))
end)

AddEventHandler('bigbox:server:playerUnloaded', function(src)
    TriggerEvent('QBCore:Server:OnPlayerUnload', src)
    TriggerClientEvent('QBCore:Client:OnPlayerUnload', src)
end)

AddEventHandler('bigbox:server:jobUpdated', function(src, job)
    local qb = BR.QBGroup(job)
    TriggerEvent('QBCore:Server:OnJobUpdate', src, qb)
    TriggerClientEvent('QBCore:Client:OnJobUpdate', src, qb)
end)

AddEventHandler('bigbox:server:gangUpdated', function(src, gang)
    local qb = BR.QBGroup(gang)
    TriggerEvent('QBCore:Server:OnGangUpdate', src, qb)
    TriggerClientEvent('QBCore:Client:OnGangUpdate', src, qb)
end)

AddEventHandler('bigbox:server:dutyChange', function(src, onDuty)
    TriggerClientEvent('QBCore:Client:SetDuty', src, onDuty)
end)

AddEventHandler('bigbox:server:moneyChange', function(src, mtype, amount, op, reason)
    TriggerEvent('QBCore:Server:OnMoneyChange', src, mtype, amount, op, reason)
    TriggerClientEvent('hud:client:OnMoneyChange', src, mtype, amount, op == 'remove')
end)

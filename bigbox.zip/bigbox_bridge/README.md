# bigbox_bridge — scripts de qb-core / Qbox rodando no bigbox

Resource separado: o bigbox continua limpo e a compatibilidade é opcional (basta não dar `ensure` nele).

## Instalação
```
ensure ox_lib
ensure oxmysql
ensure bigbox
ensure bigbox_bridge      # depois do bigbox e ANTES dos scripts de QBCore
ensure seu_script_qb
```
Não use junto com o `qb-core` ou `qbx_core` originais: a ponte declara `provide` para os dois nomes.

## O que funciona
**Servidor** (`exports['qb-core']:GetCoreObject()` e `exports.qbx_core:*`):
- `Functions`: `GetPlayer`, `GetPlayerByCitizenId`, `GetPlayers`, `GetQBPlayers`, `GetDutyCount`, `GetIdentifier`, `Notify`, `HasItem`, `CreateCallback`, `CreateUseableItem`
- `Commands.Add(...)` (permissão diferente de `user` exige admin do bigbox)
- `Shared.Items / Jobs / Gangs` — **uma tabela única, atualizada no lugar** a cada edição do painel (referências guardadas por scripts continuam válidas)
- Jogador: `PlayerData` (charinfo, money, job, gang, items com `slot`, metadata) e `Functions` (`AddMoney`, `RemoveMoney`, `SetMoney`, `GetMoney`, `AddItem`, `RemoveItem`, `GetItemByName`, `GetItemsByName`, `SetJob`, `SetGang`, `SetJobDuty`, `SetMetaData`, `GetMetaData`, `Save`, `Logout`, `Notify`)
- Exports qbx: `GetPlayer`, `GetPlayerByCitizenId`, `GetQBPlayers`, `Notify`, `GetJobs`, `GetGangs`

**Cliente**: `Functions.GetPlayerData`, `Notify`, `TriggerCallback`, `HasItem`, `Progressbar`, `Shared` (também atualizado em tempo real).

**Eventos traduzidos**: `QBCore:Server:PlayerLoaded`, `OnPlayerUnload`, `OnJobUpdate`, `OnGangUpdate`, `OnMoneyChange`,
`QBCore:Client:OnPlayerLoaded`, `OnPlayerUnload`, `OnJobUpdate`, `OnGangUpdate`, `SetDuty`, `QBCore:Player:SetPlayerData`.

## Limites (compatibilidade parcial)
- Inventário sem `info` por item: `PlayerData.items[n].info = {}`. Scripts que dependem de metadados por item ou de `qb-inventory` não funcionam direito.
- Sem `qb-target`, `qb-menu`, `qb-input` etc. (são outros resources).
- Objetos jogador são "fotos" do momento da chamada: chame `GetPlayer` de novo para ver dados atualizados.
- Não há jogadores offline (`GetOfflinePlayer`) nem `QBCore.Player.*`.
- Tabelas do banco são `bigbox_*`, não `players`: scripts que consultam a tabela do QBCore direto no SQL precisam ser ajustados.

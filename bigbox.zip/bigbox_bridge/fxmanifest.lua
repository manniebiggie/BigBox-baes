fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'bigbox_bridge'
author 'BigBox'
description 'Ponte de compatibilidade: scripts de qb-core e qbx_core rodando sobre o bigbox'
version '2.0.0'

-- Faz scripts que chamam exports['qb-core'] / exports.qbx_core usarem esta ponte.
provide 'qb-core'
provide 'qbx_core'

dependencies {
    'bigbox',
    'ox_lib',
}

shared_scripts {
    '@ox_lib/init.lua',
    'shared/convert.lua',
}

server_scripts {
    'server/main.lua',
}

client_scripts {
    'client/main.lua',
}

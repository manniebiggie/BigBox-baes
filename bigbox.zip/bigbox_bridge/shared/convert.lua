-- ============================================================
-- bigbox_bridge | shared/convert.lua
-- Converte os dados do bigbox para o formato esperado por scripts de QBCore.
-- ============================================================

BR = BR or {}

local typeMap = {
    primary = 'inform', info = 'inform', inform = 'inform',
    success = 'success', error = 'error', warning = 'warning',
}

function BR.NotifyType(t)
    return typeMap[t or 'primary'] or 'inform'
end

function BR.Round(n, places)
    local m = 10 ^ (places or 0)
    return math.floor((n or 0) * m + 0.5) / m
end

function BR.Trim(s)
    if not s then return nil end
    return (tostring(s):gsub('^%s*(.-)%s*$', '%1'))
end

--- Emprego/gangue no formato QB.
function BR.QBGroup(g)
    if not g then return {} end
    return {
        name = g.name,
        label = g.label,
        type = g.type,
        onduty = g.onduty,
        payment = g.payment,
        isboss = g.isboss,
        grade = { name = g.grade and g.grade.name, level = g.grade and g.grade.level },
    }
end

--- Item do inventário no formato QB.
function BR.QBItem(it, slot)
    return {
        name = it.name,
        amount = it.count,
        label = it.label,
        weight = it.weight,
        slot = slot,
        type = 'item',
        useable = it.usable and true or false,
        unique = false,
        image = it.name .. '.png',
        description = it.description,
        info = {},
    }
end

--- PlayerData completo no formato QB.
function BR.ToQBPlayerData(d, license)
    local items = {}
    for i, it in ipairs(d.inventory or {}) do items[i] = BR.QBItem(it, it.slot or i) end

    local meta = {
        hunger = 100, thirst = 100, stress = 0, armor = 0,
        isdead = false, inlaststand = false, ishandcuffed = false, injail = 0,
    }
    for k, v in pairs(d.metadata or {}) do meta[k] = v end

    local ci = d.charinfo or {}
    return {
        source = d.source,
        citizenid = d.citizenid,
        license = license,
        name = ((ci.firstname or '') .. ' ' .. (ci.lastname or '')),
        cid = 1,
        charinfo = {
            firstname = ci.firstname, lastname = ci.lastname,
            birthdate = ci.birthdate, gender = ci.gender,
            nationality = '', phone = '', account = '',
        },
        money = d.money,
        job = BR.QBGroup(d.job),
        gang = BR.QBGroup(d.gang),
        items = items,
        metadata = meta,
    }
end

--- QBCore.Shared (Items / Jobs / Gangs) a partir dos registros do bigbox.
function BR.BuildShared(items, jobs, gangs)
    local Items = {}
    for name, it in pairs(items or {}) do
        Items[name] = {
            name = name, label = it.label, weight = it.weight or 0, type = 'item',
            image = name .. '.png', unique = false, useable = it.usable and true or false,
            shouldClose = true, description = it.description or '',
        }
    end

    local function conv(list)
        local out = {}
        for name, g in pairs(list or {}) do
            local grades = {}
            for _, gr in ipairs(g.grades or {}) do
                grades[tostring(gr.grade)] = { name = gr.name, payment = gr.payment, isboss = gr.boss and true or false }
            end
            out[name] = { label = g.label, type = g.type, defaultDuty = true, offDutyPay = false, grades = grades }
        end
        return out
    end

    return Items, conv(jobs), conv(gangs)
end

local function replaceContents(dst, src)
    for k in pairs(dst) do dst[k] = nil end
    for k, v in pairs(src) do dst[k] = v end
end

--- Atualiza um QBCore.Shared EXISTENTE sem trocar as tabelas.
--- Scripts de QBCore guardam referências como `local Items = QBCore.Shared.Items`;
--- se a tabela fosse substituída, essas referências ficariam com dados velhos.
function BR.FillShared(shared, items, jobs, gangs)
    local i, j, g = BR.BuildShared(items, jobs, gangs)
    shared.Items = shared.Items or {}
    shared.Jobs = shared.Jobs or {}
    shared.Gangs = shared.Gangs or {}
    replaceContents(shared.Items, i)
    replaceContents(shared.Jobs, j)
    replaceContents(shared.Gangs, g)
    shared.Round = BR.Round
    shared.Trim = BR.Trim
end

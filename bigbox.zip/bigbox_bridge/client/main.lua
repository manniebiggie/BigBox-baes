-- ============================================================
-- bigbox_bridge | client/main.lua
-- API de cliente do qb-core: GetPlayerData, Notify, TriggerCallback, Progressbar...
-- ============================================================

local Shared = { Items = {}, Jobs = {}, Gangs = {}, Round = BR.Round, Trim = BR.Trim }
local QBCore = { Functions = {}, Shared = Shared }
local sharedReady = false

local function getPD()
    local d = exports.bigbox:GetPlayerData()
    if not d or not d.citizenid then return {} end
    return BR.ToQBPlayerData(d, nil)
end

-- ---------------- Functions ----------------

function QBCore.Functions.GetPlayerData(cb)
    local pd = getPD()
    if cb then cb(pd) else return pd end
end

function QBCore.Functions.Notify(text, ntype, length)
    local title, desc
    if type(text) == 'table' then
        desc = text.text or text[1] or ''
        title = text.caption
    else
        desc = tostring(text)
    end
    lib.notify({
        title = title, description = desc,
        type = BR.NotifyType(ntype), duration = length or 5000, position = 'top-right',
    })
end

--- TriggerCallback(name, function(resultado) end, ...)
function QBCore.Functions.TriggerCallback(name, cb, ...)
    local args = { ... }
    CreateThread(function()
        local result = lib.callback.await(name, false, table.unpack(args))
        if cb then cb(result) end
    end)
end

function QBCore.Functions.HasItem(items, amount)
    amount = amount or 1
    if type(items) == 'string' then items = { items } end
    local have = {}
    for _, it in ipairs(getPD().items or {}) do have[it.name] = it.amount end
    for _, name in pairs(items or {}) do
        if (have[name] or 0) < amount then return false end
    end
    return true
end

function QBCore.Functions.Progressbar(name, label, duration, useWhileDead, canCancel, disableControls, animation, prop, propTwo, onFinish, onCancel)
    CreateThread(function()
        local dc = disableControls or {}
        local opts = {
            duration = duration, label = label, useWhileDead = useWhileDead, canCancel = canCancel,
            disable = { move = dc.disableMovement, car = dc.disableCarMovement, combat = dc.disableCombat, mouse = dc.disableMouse },
        }
        if animation and animation.animDict then
            opts.anim = { dict = animation.animDict, clip = animation.anim, flag = animation.flags }
        end
        if lib.progressBar(opts) then
            if onFinish then onFinish() end
        else
            if onCancel then onCancel() end
        end
    end)
end

-- ---------------- Shared (carregado do servidor) ----------------
-- Tabela única, preenchida no lugar: scripts que guardaram QBCore.Shared.Items
-- numa variável continuam recebendo as atualizações.

local function applyShared(res)
    if res and res.items then
        BR.FillShared(Shared, res.items, res.jobs, res.gangs)
        if next(Shared.Items) then sharedReady = true end
    end
end

local function fetchShared()
    local ok, res = pcall(lib.callback.await, 'bigbox_bridge:getShared', false)
    if ok then applyShared(res) end
end

CreateThread(function()
    -- Tenta por até ~30s: o servidor pode ainda estar carregando o banco.
    for _ = 1, 30 do
        fetchShared()
        if sharedReady then return end
        Wait(1000)
    end
    sharedReady = true -- não trava scripts para sempre; o evento abaixo corrige depois
end)

-- Edições feitas no painel do bigbox chegam aqui.
RegisterNetEvent('bigbox_bridge:client:sharedUpdated', applyShared)

exports('GetCoreObject', function()
    if not sharedReady then
        -- Espera um pouco se o script chamou cedo demais (ignorado fora de thread)
        pcall(function()
            local t = GetGameTimer()
            while not sharedReady and GetGameTimer() - t < 5000 do Wait(0) end
        end)
    end
    return QBCore
end)

-- ---------------- Eventos: bigbox -> QBCore ----------------

RegisterNetEvent('bigbox:client:setPlayerData', function(data)
    if data and data.citizenid then
        TriggerEvent('QBCore:Player:SetPlayerData', BR.ToQBPlayerData(data, nil))
    end
end)

-- Evento local disparado pelo bigbox depois do spawn
AddEventHandler('bigbox:client:playerLoaded', function()
    TriggerEvent('QBCore:Client:OnPlayerLoaded')
end)

-- ============================================================
-- BigBox | client/inventory.lua
-- Inventário em NUI (html/): Corpo (seu personagem em 3D + saúde),
-- Jogador (slots com arrastar e soltar) e Chão (itens largados).
-- A interface só PEDE as ações; quem decide é o servidor.
-- ============================================================

local isOpen = false
local ground = nil -- { id, items } da pilha mais próxima, ou nil

local function toast(msg, ntype)
    lib.notify({ description = msg, type = ntype or 'inform', position = Config.Notify.position })
end

--- Saúde, colete, fome e sede em % (a vida do GTA começa em 100: 100 = morto).
local function vitals()
    local ped = PlayerPedId()
    local max = GetEntityMaxHealth(ped) - 100
    local hp = math.max(0, GetEntityHealth(ped) - 100)
    local md = BB.PlayerData.metadata or {}
    return {
        health = max > 0 and math.min(100, math.floor(hp / max * 100)) or 0,
        armor = GetPedArmour(ped),
        hunger = tonumber(md.hunger) or 100,
        thirst = tonumber(md.thirst) or 100,
    }
end

local function payload()
    local d = BB.PlayerData
    local money = {}
    for key, cfg in pairs(Config.Money) do
        money[#money + 1] = { key = key, label = cfg.label, amount = d.money and d.money[key] or 0 }
    end
    table.sort(money, function(a, b) return a.key < b.key end)

    local ci = d.charinfo or {}
    return {
        items = d.inventory or {},
        slots = d.slots or Config.Inventory.Slots,
        weight = d.weight or 0,
        maxWeight = d.maxWeight or Config.Inventory.MaxWeight,
        money = money,
        name = ('%s %s'):format(ci.firstname or '', ci.lastname or ''),
        citizenid = d.citizenid,
        job = d.job and ('%s - %s'):format(d.job.label, d.job.grade.name) or '',
        ground = ground,
        vitals = vitals(),
    }
end

local UI_KEYS = {
    'ui_player', 'ui_ground', 'ui_body', 'ui_personal', 'ui_name', 'ui_citizen', 'ui_job',
    'ui_health', 'ui_armor', 'ui_hunger', 'ui_thirst', 'ui_amount', 'ui_amount_hint',
    'ui_ground_empty', 'ui_close', 'inv_use', 'inv_give', 'inv_drop', 'weight',
}

local function uiStrings()
    local out = {}
    for _, k in ipairs(UI_KEYS) do out[k] = BB.T(k) end
    return out
end

local function refresh()
    if isOpen then SendNUIMessage({ action = 'update', data = payload() }) end
end

local function close()
    if not isOpen then return end
    isOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
    BB.StopPreview()
end

local function open()
    if isOpen or not BB.Spawned or BB.IsDead then return end
    if not BB.PlayerData or not BB.PlayerData.citizenid then return end
    isOpen = true

    ground = lib.callback.await('bigbox:drop:getNearby', false)
    SetNuiFocus(true, true)
    BB.StartPreview()
    SendNUIMessage({
        action = 'open',
        data = payload(),
        ui = uiStrings(),
        config = {
            imagePath = Config.Inventory.ImagePath,
            closeKey = Config.Keys.inventory,
            preview = Config.Inventory.Preview and true or false,
        },
    })

    -- Atualiza a saúde enquanto estiver aberto; fecha sozinho se o jogador morrer.
    CreateThread(function()
        while isOpen do
            SendNUIMessage({ action = 'vitals', data = vitals() })
            if BB.IsDead or not BB.Spawned then close() end
            Wait(400)
        end
    end)
end

-- Mudanças de dados vindas do servidor (item usado, dinheiro etc.) atualizam a tela aberta.
-- (O handler de client/main.lua é registrado antes e já atualizou BB.PlayerData.)
RegisterNetEvent('bigbox:client:setPlayerData', refresh)

-- ---------------- Ações pedidas pela interface ----------------

--- Jogador mais próximo dentro da distância de entrega (ID de servidor) ou nil.
local function nearestPlayer()
    local myCoords = GetEntityCoords(PlayerPedId())
    local maxDist = Config.Inventory.GiveDistance or 3.0
    local nearest, best
    for _, id in ipairs(GetActivePlayers()) do
        if id ~= PlayerId() then
            local dist = #(GetEntityCoords(GetPlayerPed(id)) - myCoords)
            if dist <= maxDist and (not best or dist < best) then
                nearest, best = GetPlayerServerId(id), dist
            end
        end
    end
    return nearest
end

local function fail(err)
    if err then toast(BB.T(err), 'error') end
end

RegisterNUICallback('close', function(_, cb)
    close()
    cb('ok')
end)

RegisterNUICallback('move', function(data, cb)
    lib.callback.await('bigbox:moveItem', false, data.name, data.slot)
    cb('ok')
end)

RegisterNUICallback('use', function(data, cb)
    local ok, err = lib.callback.await('bigbox:useItem', false, data.name)
    if not ok then fail(err) end
    cb('ok')
end)

RegisterNUICallback('give', function(data, cb)
    local target = nearestPlayer()
    if not target then
        toast(BB.T('inv_nobody_near'), 'error')
    else
        local ok, err = lib.callback.await('bigbox:giveItem', false, target, data.name, data.amount)
        if not ok then fail(err) end
    end
    cb('ok')
end)

RegisterNUICallback('drop', function(data, cb)
    local ok, result = lib.callback.await('bigbox:dropItem', false, data.name, data.amount)
    if ok then
        ground = result
        refresh()
    else
        fail(result)
    end
    cb('ok')
end)

RegisterNUICallback('pickup', function(data, cb)
    if ground then
        local ok, result = lib.callback.await('bigbox:pickupItem', false, ground.id, data.name, data.amount)
        if ok then
            ground = result
            refresh()
        else
            fail(result)
        end
    end
    cb('ok')
end)

-- ---------------- Teclas ----------------

RegisterCommand('inventario', function()
    if isOpen then close() else open() end
end, false)
RegisterKeyMapping('inventario', BB.T('open_inventory'), 'keyboard', Config.Keys.inventory)

-- Atalhos 1-5: usam o item que está no slot correspondente
if Config.Keys.hotbar then
    for slot = 1, 5 do
        local cmd = 'bigbox_hotbar' .. slot
        RegisterCommand(cmd, function()
            if isOpen or not BB.Spawned or BB.IsDead then return end
            for _, it in ipairs(BB.PlayerData.inventory or {}) do
                if it.slot == slot then
                    local ok, err = lib.callback.await('bigbox:useItem', false, it.name)
                    if not ok then fail(err) end
                    return
                end
            end
        end, false)
        RegisterKeyMapping(cmd, BB.T('hotbar_key', slot), 'keyboard', tostring(slot))
    end
end

AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() and isOpen then SetNuiFocus(false, false) end
end)

exports('IsInventoryOpen', function() return isOpen end)

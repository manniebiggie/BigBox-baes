-- ============================================================
-- BigBox | client/death.lua
-- Morte e renascimento no hospital. Desligue com Config.Death.enabled = false
-- se usar outro script de ambulância/morte.
-- ============================================================

local lastText

local function showText(text)
    if text ~= lastText then
        lastText = text
        lib.showTextUI(text)
    end
end

local function hideText()
    if lastText then
        lastText = nil
        lib.hideTextUI()
    end
end

--- Reanima o jogador. Sem coordenadas, reanima onde ele está.
local function revive(x, y, z, heading)
    local ped = PlayerPedId()
    if not x then
        local c = GetEntityCoords(ped)
        x, y, z, heading = c.x, c.y, c.z, GetEntityHeading(ped)
    end
    NetworkResurrectLocalPlayer(x, y, z, heading or 0.0, true, false)
    ped = PlayerPedId()
    ClearPedBloodDamage(ped)
    SetEntityHealth(ped, GetEntityMaxHealth(ped))
    ClearPedTasksImmediately(ped)
    FreezeEntityPosition(ped, false)
end

local function respawnAtHospital()
    local ok, pos = lib.callback.await('bigbox:respawn', false)
    if not ok then
        lib.notify({ description = BB.T(pos or 'respawn_wait'), type = 'error', position = Config.Notify.position })
        return false
    end
    DoScreenFadeOut(500)
    while not IsScreenFadedOut() do Wait(0) end
    revive(pos.x, pos.y, pos.z, pos.w)
    BB.IsDead = false
    Wait(500)
    DoScreenFadeIn(500)
    return true
end

local function onDeath()
    BB.IsDead = true
    lib.callback.await('bigbox:setDead', false, true)

    local readyAt = GetGameTimer() + (Config.Death.respawnTime or 60) * 1000
    while BB.IsDead and BB.Spawned do
        -- Alguém reanimou o jogador por fora (outro script): sincroniza e sai.
        if not IsEntityDead(PlayerPedId()) then
            BB.IsDead = false
            lib.callback.await('bigbox:setDead', false, false)
            break
        end

        local left = math.ceil((readyAt - GetGameTimer()) / 1000)
        if left > 0 then
            showText(BB.T('death_wait', left))
        else
            showText(BB.T('death_respawn'))
            if IsControlJustReleased(0, Config.Keys.respawn or 38) and respawnAtHospital() then break end
        end
        Wait(0)
    end
    hideText()
end

CreateThread(function()
    while true do
        if Config.Death.enabled and BB.Spawned and not BB.IsDead and IsEntityDead(PlayerPedId()) then
            onDeath()
        end
        Wait(500)
    end
end)

-- /revive (admin) ou painel admin
RegisterNetEvent('bigbox:client:revive', function()
    if not BB.Spawned then return end
    revive()
    BB.IsDead = false
    lib.callback.await('bigbox:setDead', false, false)
    lib.notify({ description = BB.T('revived'), type = 'success', position = Config.Notify.position })
end)

-- ============================================================
-- BigBox | client/admin.lua
-- Painel admin (/bigadmin): itens, empregos, gangues e jogadores online,
-- tudo sem mexer em arquivo. Tudo é validado e salvo pelo servidor.
-- Edições ficam no banco e SOBRESCREVEM a config; excluir volta ao original
-- (registros que só existem no config.lua não podem ser excluídos pelo painel).
-- ============================================================

local mainMenu, itemsMenu, groupsMenu, groupActions, gradesMenu, playersMenu

local function toast(msg, t)
    lib.notify({ description = msg, type = t or 'inform', position = Config.Notify.position })
end

--- Mostra "salvo" ou o erro. Devolve o próprio ok para facilitar o uso.
local function result(ok, err)
    if ok then
        toast(BB.T('admin_saved'), 'success')
    else
        toast(BB.T(err or 'admin_error'), 'error')
    end
    return ok
end

local function getRegistry()
    local reg = lib.callback.await('bigbox:admin:getRegistry', false)
    if not reg then toast(BB.T('no_permission'), 'error') end
    return reg
end

local function confirmDelete(name)
    return lib.alertDialog({
        header = BB.T('admin_delete'),
        content = BB.T('admin_confirm_delete', name),
        centered = true,
        cancel = true,
    }) == 'confirm'
end

local function sourceLabel(source)
    return BB.T('admin_source_' .. (source or 'config'))
end

--- "Nome Exibido" -> "nome_exibido"
local function toKey(s)
    local k = string.lower(s or '')
    k = k:gsub('%s+', '_')
    return k
end

--- Lista { value, label } ordenada, a partir de um mapa nome -> { label }.
local function selectOptions(map)
    local names = {}
    for n in pairs(map or {}) do names[#names + 1] = n end
    table.sort(names)
    local out = {}
    for _, n in ipairs(names) do
        out[#out + 1] = { value = n, label = ('%s (%s)'):format(map[n].label or n, n) }
    end
    return out
end

-- ---------------- ITENS ----------------

local function itemForm(name, data)
    local isNew = name == nil
    data = data or { label = '', weight = 0, usable = false, description = '' }

    local input = lib.inputDialog(isNew and BB.T('admin_create') or BB.T('admin_edit'), {
        { type = 'input', label = BB.T('admin_name'), default = name, disabled = not isNew, required = true, min = 2, max = 50 },
        { type = 'input', label = BB.T('admin_label'), default = data.label, required = true, max = 60 },
        { type = 'number', label = BB.T('admin_weight'), default = data.weight, min = 0, required = true },
        { type = 'input', label = BB.T('admin_desc'), default = data.description },
        { type = 'checkbox', label = BB.T('admin_usable'), checked = data.usable },
    })
    if not input then return end

    local key = isNew and toKey(input[1]) or name
    local ok, err = lib.callback.await('bigbox:admin:saveItem', false, key, {
        label = input[2], weight = input[3], description = input[4], usable = input[5],
    })
    result(ok, err)
end

local function itemActions(name, it, source)
    lib.registerContext({
        id = 'bigbox_admin_item_actions',
        title = ('%s (%s)'):format(it.label, name),
        menu = 'bigbox_admin_items',
        options = {
            { title = BB.T('admin_edit'), icon = 'pen', onSelect = function() itemForm(name, it) itemsMenu() end },
            { title = BB.T('admin_delete'), icon = 'trash', onSelect = function()
                if source == 'config' then
                    toast(BB.T('admin_config_only'), 'error')
                elseif confirmDelete(name) then
                    local ok, err = lib.callback.await('bigbox:admin:deleteItem', false, name)
                    toast(ok and BB.T('admin_deleted') or BB.T(err or 'admin_error'), ok and 'success' or 'error')
                end
                itemsMenu()
            end },
        },
    })
    lib.showContext('bigbox_admin_item_actions')
end

itemsMenu = function()
    local reg = getRegistry()
    if not reg then return end

    local names = {}
    for n in pairs(reg.items) do names[#names + 1] = n end
    table.sort(names)

    local options = {
        { title = BB.T('admin_create'), icon = 'plus', onSelect = function() itemForm() itemsMenu() end },
    }
    for _, n in ipairs(names) do
        local it = reg.items[n]
        local source = reg.sources.items[n]
        options[#options + 1] = {
            title = ('%s (%s)'):format(it.label, n),
            description = ('%s g%s • %s'):format(it.weight or 0, it.usable and ' • ' .. BB.T('admin_usable') or '', sourceLabel(source)),
            icon = 'box',
            onSelect = function() itemActions(n, it, source) end,
        }
    end

    lib.registerContext({ id = 'bigbox_admin_items', title = BB.T('admin_items'), menu = 'bigbox_admin', options = options })
    lib.showContext('bigbox_admin_items')
end

-- ---------------- EMPREGOS / GANGUES ----------------

local function regKey(kind) return kind == 'job' and 'jobs' or 'gangs' end

local function saveGroup(kind, name, g)
    local ok, err = lib.callback.await('bigbox:admin:saveGroup', false, kind, name, {
        label = g.label, type = g.type, grades = g.grades,
    })
    return result(ok, err)
end

local function groupInfoForm(kind, name, g)
    local isNew = name == nil
    g = g or {
        label = '',
        type = kind == 'job' and 'civil' or 'gang',
        grades = { { grade = 0, name = 'Cargo 0', payment = 0, boss = false } },
    }

    local input = lib.inputDialog(isNew and BB.T('admin_create') or BB.T('admin_edit'), {
        { type = 'input', label = BB.T('admin_name'), default = name, disabled = not isNew, required = true, min = 2, max = 50 },
        { type = 'input', label = BB.T('admin_label'), default = g.label, required = true, max = 60 },
        { type = 'input', label = BB.T('admin_type'), default = g.type, required = true, max = 30 },
    })
    if not input then return end

    local key = isNew and toKey(input[1]) or name
    g.label, g.type = input[2], input[3]
    saveGroup(kind, key, g)
end

local function gradeForm(kind, name, g, grade)
    local isNew = grade == nil
    local fields = {
        { type = 'number', label = BB.T('admin_grade_level'), default = grade and grade.grade or #g.grades, min = 0, max = 50, required = true },
        { type = 'input', label = BB.T('admin_grade_name'), default = grade and grade.name or '', required = true, max = 60 },
        { type = 'number', label = BB.T('admin_grade_pay'), default = grade and grade.payment or 0, min = 0, required = true },
        { type = 'checkbox', label = BB.T('admin_grade_boss'), checked = grade and grade.boss or false },
    }
    if not isNew then
        fields[5] = { type = 'checkbox', label = BB.T('admin_grade_remove') }
    end

    local input = lib.inputDialog(BB.T('admin_grades'), fields)
    if not input then return end

    local list = {}
    for _, gr in ipairs(g.grades) do
        if not (grade and gr.grade == grade.grade) then list[#list + 1] = gr end
    end
    if not input[5] then
        -- Se já existir outro cargo com esse nível, ele é substituído (não duplica).
        local level = math.floor(input[1])
        for i = #list, 1, -1 do
            if list[i].grade == level then table.remove(list, i) end
        end
        list[#list + 1] = { grade = level, name = input[2], payment = input[3], boss = input[4] and true or false }
    end
    table.sort(list, function(a, b) return a.grade < b.grade end)
    g.grades = list

    saveGroup(kind, name, g)
end

gradesMenu = function(kind, name)
    local reg = getRegistry()
    if not reg then return end
    local g = reg[regKey(kind)][name]
    if not g then return groupsMenu(kind) end

    local options = {
        { title = BB.T('admin_add_grade'), icon = 'plus', onSelect = function() gradeForm(kind, name, g) gradesMenu(kind, name) end },
    }
    for _, gr in ipairs(g.grades) do
        options[#options + 1] = {
            title = ('[%d] %s'):format(gr.grade, gr.name),
            description = ('$%s%s'):format(gr.payment, gr.boss and ' • boss' or ''),
            icon = gr.boss and 'star' or 'user',
            onSelect = function() gradeForm(kind, name, g, gr) gradesMenu(kind, name) end,
        }
    end

    lib.registerContext({
        id = 'bigbox_admin_grades',
        title = ('%s - %s'):format(g.label, BB.T('admin_grades')),
        menu = 'bigbox_admin_group_actions',
        options = options,
    })
    lib.showContext('bigbox_admin_grades')
end

groupActions = function(kind, name, g, source)
    lib.registerContext({
        id = 'bigbox_admin_group_actions',
        title = ('%s (%s)'):format(g.label, name),
        menu = 'bigbox_admin_groups',
        options = {
            { title = BB.T('admin_edit'), icon = 'pen', onSelect = function() groupInfoForm(kind, name, g) groupsMenu(kind) end },
            { title = BB.T('admin_grades'), icon = 'layer-group', onSelect = function() gradesMenu(kind, name) end },
            { title = BB.T('admin_delete'), icon = 'trash', onSelect = function()
                if source == 'config' then
                    toast(BB.T('admin_config_only'), 'error')
                elseif confirmDelete(name) then
                    local ok, err = lib.callback.await('bigbox:admin:deleteGroup', false, kind, name)
                    toast(ok and BB.T('admin_deleted') or BB.T(err or 'admin_error'), ok and 'success' or 'error')
                end
                groupsMenu(kind)
            end },
        },
    })
    lib.showContext('bigbox_admin_group_actions')
end

groupsMenu = function(kind)
    local reg = getRegistry()
    if not reg then return end

    local list = reg[regKey(kind)]
    local sources = reg.sources[regKey(kind)]
    local names = {}
    for n in pairs(list) do names[#names + 1] = n end
    table.sort(names)

    local options = {
        { title = BB.T('admin_create'), icon = 'plus', onSelect = function() groupInfoForm(kind) groupsMenu(kind) end },
    }
    for _, n in ipairs(names) do
        local g = list[n]
        options[#options + 1] = {
            title = ('%s (%s)'):format(g.label, n),
            description = ('%s • %d %s • %s'):format(g.type or '-', #g.grades, BB.T('admin_grades'), sourceLabel(sources[n])),
            icon = kind == 'job' and 'briefcase' or 'users',
            onSelect = function() groupActions(kind, n, g, sources[n]) end,
        }
    end

    lib.registerContext({
        id = 'bigbox_admin_groups',
        title = BB.T(kind == 'job' and 'admin_jobs' or 'admin_gangs'),
        menu = 'bigbox_admin',
        options = options,
    })
    lib.showContext('bigbox_admin_groups')
end

-- ---------------- JOGADORES ONLINE ----------------

local function playerAction(target, action, data)
    local ok, err = lib.callback.await('bigbox:admin:playerAction', false, target, action, data)
    return result(ok, err)
end

--- Abre um formulário e executa a ação. fields = campos do inputDialog;
--- build(input) transforma as respostas nos dados enviados ao servidor.
local function askAndRun(p, title, action, fields, build)
    local input = lib.inputDialog(title, fields)
    if not input then return end
    playerAction(p.source, action, build(input))
end

local function playerActions(p)
    local reg = getRegistry()
    if not reg then return end

    local moneyOptions = {}
    for _, m in ipairs(reg.money) do moneyOptions[#moneyOptions + 1] = { value = m.key, label = m.label } end
    local itemOptions = selectOptions(reg.items)
    local amountField = { type = 'number', label = BB.T('admin_field_amount'), min = 0, required = true }
    local moneyField = { type = 'select', label = BB.T('admin_field_money'), options = moneyOptions, required = true }
    local itemField = { type = 'select', label = BB.T('admin_field_item'), options = itemOptions, required = true, searchable = true }

    local function moneyAction(title, action)
        return function()
            askAndRun(p, title, action, { moneyField, amountField }, function(i) return { type = i[1], amount = i[2] } end)
            playersMenu()
        end
    end

    local function itemAction(title, action)
        return function()
            askAndRun(p, title, action, { itemField, { type = 'number', label = BB.T('admin_field_amount'), default = 1, min = 1, required = true } },
                function(i) return { item = i[1], amount = i[2] } end)
            playersMenu()
        end
    end

    lib.registerContext({
        id = 'bigbox_admin_player',
        title = ('[%d] %s'):format(p.source, p.charname),
        menu = 'bigbox_admin_players',
        options = {
            { title = BB.T('admin_set_job'), icon = 'briefcase', onSelect = function()
                askAndRun(p, BB.T('admin_set_job'), 'setjob', {
                    { type = 'select', label = BB.T('admin_field_job'), options = selectOptions(reg.jobs), required = true, searchable = true },
                    { type = 'number', label = BB.T('admin_grade_level'), min = 0, max = 50 },
                }, function(i) return { job = i[1], grade = i[2] } end)
                playersMenu()
            end },
            { title = BB.T('admin_set_gang'), icon = 'users', onSelect = function()
                askAndRun(p, BB.T('admin_set_gang'), 'setgang', {
                    { type = 'select', label = BB.T('admin_field_gang'), options = selectOptions(reg.gangs), required = true, searchable = true },
                    { type = 'number', label = BB.T('admin_grade_level'), min = 0, max = 50 },
                }, function(i) return { gang = i[1], grade = i[2] } end)
                playersMenu()
            end },
            { title = BB.T('admin_give_money'), icon = 'circle-plus', onSelect = moneyAction(BB.T('admin_give_money'), 'givemoney') },
            { title = BB.T('admin_remove_money'), icon = 'circle-minus', onSelect = moneyAction(BB.T('admin_remove_money'), 'removemoney') },
            { title = BB.T('admin_set_money'), icon = 'equals', onSelect = moneyAction(BB.T('admin_set_money'), 'setmoney') },
            { title = BB.T('admin_give_item'), icon = 'box', onSelect = itemAction(BB.T('admin_give_item'), 'giveitem') },
            { title = BB.T('admin_remove_item'), icon = 'box-open', onSelect = itemAction(BB.T('admin_remove_item'), 'removeitem') },
            { title = BB.T('admin_revive'), icon = 'heart-pulse', onSelect = function()
                playerAction(p.source, 'revive')
                playersMenu()
            end },
            { title = BB.T('admin_logout'), icon = 'right-from-bracket', onSelect = function()
                playerAction(p.source, 'logout')
                playersMenu()
            end },
        },
    })
    lib.showContext('bigbox_admin_player')
end

playersMenu = function()
    local list = lib.callback.await('bigbox:admin:getPlayers', false)
    if not list then return toast(BB.T('no_permission'), 'error') end

    local options = {}
    for _, p in ipairs(list) do
        options[#options + 1] = {
            title = ('[%d] %s'):format(p.source, p.charname),
            description = ('%s • %s • %s'):format(p.name, p.job, p.gang),
            icon = 'user',
            onSelect = function() playerActions(p) end,
        }
    end
    if #options == 0 then
        options[1] = { title = BB.T('admin_no_players'), icon = 'ban', readOnly = true }
    end

    lib.registerContext({ id = 'bigbox_admin_players', title = BB.T('admin_players'), menu = 'bigbox_admin', options = options })
    lib.showContext('bigbox_admin_players')
end

-- ---------------- MENU PRINCIPAL ----------------

mainMenu = function()
    lib.registerContext({
        id = 'bigbox_admin',
        title = BB.T('admin_title'),
        options = {
            { title = BB.T('admin_players'), icon = 'user-group', onSelect = playersMenu },
            { title = BB.T('admin_items'), icon = 'box', onSelect = itemsMenu },
            { title = BB.T('admin_jobs'), icon = 'briefcase', onSelect = function() groupsMenu('job') end },
            { title = BB.T('admin_gangs'), icon = 'users', onSelect = function() groupsMenu('gang') end },
            { title = BB.T('admin_reload'), icon = 'rotate', onSelect = function()
                local ok = lib.callback.await('bigbox:admin:reload', false)
                toast(ok and BB.T('admin_reloaded') or BB.T('no_permission'), ok and 'success' or 'error')
            end },
        },
    })
    lib.showContext('bigbox_admin')
end

RegisterCommand('bigadmin', function()
    if lib.callback.await('bigbox:admin:isAdmin', false) then
        mainMenu()
    else
        toast(BB.T('no_permission'), 'error')
    end
end, false)

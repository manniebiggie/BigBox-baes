-- ============================================================
-- BigBox | client/drops.lua
-- Mostra um saquinho no chão onde há itens largados.
-- Só cria o objeto quando o jogador está perto (economiza recursos).
-- ============================================================

local drops = {}   -- [id] = { x, y, z }
local props = {}   -- [id] = entidade

local SHOW_DISTANCE = 50.0

local function removeProp(id)
    local obj = props[id]
    if obj and DoesEntityExist(obj) then DeleteEntity(obj) end
    props[id] = nil
end

local function createProp(id, c)
    local model = joaat(Config.Drops.prop or 'prop_paper_bag_01')
    if not pcall(lib.requestModel, model, 3000) then return end -- ox_lib dá erro no timeout
    local obj = CreateObject(model, c.x, c.y, c.z, false, false, false)
    SetModelAsNoLongerNeeded(model)
    if not obj or obj == 0 then return end
    PlaceObjectOnGroundProperly(obj)
    FreezeEntityPosition(obj, true)
    SetEntityCollision(obj, false, false)
    props[id] = obj
end

RegisterNetEvent('bigbox:client:dropSync', function(list)
    for id in pairs(props) do removeProp(id) end
    drops = {}
    for _, d in ipairs(list or {}) do drops[d.id] = { x = d.x, y = d.y, z = d.z } end
end)

RegisterNetEvent('bigbox:client:dropUpdate', function(id, coords)
    if coords then
        drops[id] = coords
    else
        drops[id] = nil
        removeProp(id)
    end
end)

CreateThread(function()
    while true do
        Wait(1000)
        if BB.Spawned then
            local me = GetEntityCoords(PlayerPedId())
            for id, c in pairs(drops) do
                local near = #(me - vec3(c.x, c.y, c.z)) < SHOW_DISTANCE
                if near and not props[id] then
                    createProp(id, c)
                elseif not near and props[id] then
                    removeProp(id)
                end
            end
        end
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    for id in pairs(props) do removeProp(id) end
end)

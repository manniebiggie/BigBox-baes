-- ============================================================
-- BigBox | client/preview.lua
-- Mostra o SEU personagem em 3D (roupas, aparência) ao lado do inventário.
-- Técnica: um clone do ped é entregue ao menu de pausa do GTA, que o desenha
-- com iluminação própria e fundo transparente. A NUI fica por cima.
-- Desligue com Config.Inventory.Preview = false (a NUI mostra uma silhueta).
-- ============================================================

local clone
local active = false

function BB.StartPreview()
    if not Config.Inventory.Preview or active then return end
    active = true

    ActivateFrontendMenu(joaat('FE_MENU_VERSION_EMPTY_NO_BACKGROUND'), true, -1)
    local timeout = GetGameTimer() + 2000
    while not IsPauseMenuActive() and GetGameTimer() < timeout do Wait(0) end

    SetMouseCursorVisibleInMenus(false)
    ReplaceHudColourWithRgba(117, 0, 0, 0, 0) -- fundo do menu de pausa 100% transparente

    -- Clone local (não é de rede): cópia fiel das roupas e props do jogador.
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    clone = ClonePed(ped, false, false, true)
    SetEntityCoordsNoOffset(clone, c.x, c.y, c.z - 80.0, false, false, false) -- fora da vista no mapa
    SetEntityCollision(clone, false, false)
    FreezeEntityPosition(clone, true)
    SetEntityInvincible(clone, true)

    GivePedToPauseMenu(clone, 2)
    SetPauseMenuPedLighting(true)
    SetPauseMenuPedSleepState(true)

    TriggerScreenblurFadeIn(250) -- desfoca o mundo; o ped do menu continua nítido
end

function BB.StopPreview()
    if not active then return end
    active = false
    TriggerScreenblurFadeOut(250)
    SetFrontendActive(false)
    ReplaceHudColourWithRgba(117, 0, 0, 0, 186) -- cor padrão do fundo do menu de pausa
    if clone and DoesEntityExist(clone) then DeleteEntity(clone) end
    clone = nil
end

function BB.IsPreviewActive() return active end

AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() then BB.StopPreview() end
end)

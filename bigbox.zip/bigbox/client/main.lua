-- ============================================================
-- BigBox | client/main.lua
-- Fluxo de entrada: menu de personagens -> criação/seleção -> spawn.
-- Usa apenas ox_lib (menus de contexto), sem NUI própria: fácil de editar.
-- ============================================================

BB.PlayerData = {}
BB.Spawned = false
BB.IsDead = false

-- O spawn automático do spawnmanager (vem no servidor de exemplo da Cfx) brigaria com o
-- menu de personagens. Desligamos se ele existir; se não existir, o pcall ignora o erro.
CreateThread(function()
    pcall(function() exports.spawnmanager:setAutoSpawn(false) end)
end)

local function toast(msg, ntype)
    lib.notify({ description = msg, type = ntype or 'inform', position = Config.Notify.position })
end

RegisterNetEvent('bigbox:client:setPlayerData', function(data)
    BB.PlayerData = data or {}
end)

RegisterNetEvent('bigbox:client:notify', function(msg, ntype, duration)
    lib.notify({
        description = msg,
        type = ntype or 'inform',
        position = Config.Notify.position,
        duration = duration or Config.Notify.duration,
    })
end)

-- Efeito simples de cura (usado pelos itens de exemplo)
RegisterNetEvent('bigbox:client:heal', function(amount)
    if not amount or amount <= 0 then return end
    local ped = PlayerPedId()
    SetEntityHealth(ped, math.min(GetEntityMaxHealth(ped), GetEntityHealth(ped) + amount))
end)

-- ---------------- Spawn ----------------

local function spawn(info)
    DoScreenFadeOut(300)
    while not IsScreenFadedOut() do Wait(0) end

    local model = info.gender == 1 and `mp_f_freemode_01` or `mp_m_freemode_01`
    lib.requestModel(model)
    SetPlayerModel(PlayerId(), model)
    SetModelAsNoLongerNeeded(model)

    local ped = PlayerPedId()
    SetPedDefaultComponentVariation(ped)
    SetEntityCollision(ped, true, true)

    local p = info.position
    RequestCollisionAtCoord(p.x, p.y, p.z)
    SetEntityCoordsNoOffset(ped, p.x, p.y, p.z, false, false, false)
    SetEntityHeading(ped, p.w or 0.0)

    local timeout = GetGameTimer() + 5000
    while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer() < timeout do Wait(0) end

    -- Vida e colete salvos (mínimo 120 para ninguém entrar já quase morto por um valor antigo)
    local maxHealth = GetEntityMaxHealth(ped)
    SetEntityHealth(ped, math.max(120, math.min(info.health or maxHealth, maxHealth)))
    SetPedArmour(ped, info.armor or 0)

    FreezeEntityPosition(ped, false)
    SetEntityVisible(ped, true, false)
    ClearPedTasksImmediately(ped)

    -- Proteção curta contra levar dano enquanto o mundo carrega
    local protect = Config.SpawnProtection or 0
    if protect > 0 then
        SetEntityInvincible(ped, true)
        SetTimeout(protect * 1000, function() SetEntityInvincible(PlayerPedId(), false) end)
    else
        SetEntityInvincible(ped, false)
    end

    DoScreenFadeIn(500)

    BB.IsDead = false
    BB.Spawned = true
    -- Gancho para seu sistema de aparência (ex.: abrir o criador quando info.isNew == true)
    TriggerEvent('bigbox:client:playerLoaded', info)
    toast(BB.T('char_welcome', info.name or ''), 'success')
end

-- ---------------- Menu de personagens ----------------

local showCharacterMenu

local function selectCharacter(citizenid)
    local info = lib.callback.await('bigbox:selectCharacter', false, citizenid)
    if not info then
        toast(BB.T('char_error'), 'error')
        return showCharacterMenu()
    end
    spawn(info)
end

local function createCharacter()
    local input = lib.inputDialog(BB.T('create_character'), {
        { type = 'input', label = BB.T('firstname'), required = true, min = 2, max = 20 },
        { type = 'input', label = BB.T('lastname'), required = true, min = 2, max = 20 },
        { type = 'date', label = BB.T('birthdate'), format = 'YYYY-MM-DD', returnString = true, required = true },
        { type = 'select', label = BB.T('gender'), required = true, options = {
            { value = '0', label = BB.T('male') },
            { value = '1', label = BB.T('female') },
        } },
    })
    if not input then return showCharacterMenu() end

    local cid, err = lib.callback.await('bigbox:createCharacter', false, {
        firstname = input[1], lastname = input[2], birthdate = input[3], gender = input[4],
    })
    if not cid then
        toast(BB.T(err or 'char_invalid'), 'error')
        return showCharacterMenu()
    end
    toast(BB.T('char_created'), 'success')
    selectCharacter(cid)
end

--- Submenu "Jogar / Excluir" (só aparece com Config.AllowDeleteCharacter = true).
local function characterActions(c)
    local fullName = ('%s %s'):format(c.firstname, c.lastname)
    lib.registerContext({
        id = 'bigbox_char_actions',
        title = fullName,
        menu = 'bigbox_char_menu',
        canClose = false,
        options = {
            { title = BB.T('char_play'), icon = 'play', onSelect = function() selectCharacter(c.citizenid) end },
            { title = BB.T('char_delete'), icon = 'trash', onSelect = function()
                local confirm = lib.alertDialog({
                    header = BB.T('char_delete'),
                    content = BB.T('char_delete_confirm', fullName),
                    centered = true,
                    cancel = true,
                })
                if confirm == 'confirm' then
                    local ok = lib.callback.await('bigbox:deleteCharacter', false, c.citizenid)
                    toast(ok and BB.T('char_deleted') or BB.T('char_error'), ok and 'success' or 'error')
                end
                showCharacterMenu()
            end },
        },
    })
    lib.showContext('bigbox_char_actions')
end

showCharacterMenu = function()
    local data = lib.callback.await('bigbox:getCharacters', false)
    local options = {}

    for _, c in ipairs(data.chars) do
        options[#options + 1] = {
            title = ('%s %s'):format(c.firstname, c.lastname),
            description = BB.T('char_info', c.citizenid, c.job),
            icon = 'user',
            onSelect = function()
                if data.canDelete then return characterActions(c) end
                selectCharacter(c.citizenid)
            end,
        }
    end

    if #data.chars < data.max then
        options[#options + 1] = {
            title = BB.T('create_character'),
            icon = 'plus',
            onSelect = createCharacter,
        }
    end

    lib.registerContext({
        id = 'bigbox_char_menu',
        title = BB.T('char_menu_title'),
        canClose = false,
        options = options,
    })
    lib.showContext('bigbox_char_menu')
end

--- Prepara a "cena" (tela preta, ped escondido e protegido) e abre o menu.
local function openCharacterMenu()
    BB.Spawned = false
    BB.IsDead = false
    BB.PlayerData = {}
    pcall(lib.hideTextUI)

    DoScreenFadeOut(0)
    ShutdownLoadingScreen()
    ShutdownLoadingScreenNui()

    local ped = PlayerPedId()
    local s = Config.DefaultSpawn
    SetEntityCoordsNoOffset(ped, s.x, s.y, s.z, false, false, false)
    FreezeEntityPosition(ped, true)
    SetEntityVisible(ped, false, false)
    SetEntityInvincible(ped, true)   -- ninguém consegue ferir quem está na seleção de personagem
    SetEntityCollision(ped, false, false)
    Wait(300)
    DoScreenFadeIn(500)

    showCharacterMenu()
end

RegisterNetEvent('bigbox:client:openCharacterMenu', function()
    CreateThread(openCharacterMenu)
end)

CreateThread(function()
    while not NetworkIsPlayerActive(PlayerId()) do Wait(100) end
    openCharacterMenu()
end)

-- ---------------- Exports ----------------

exports('GetPlayerData', function() return BB.PlayerData end)
exports('IsSpawned', function() return BB.Spawned end)
exports('IsDead', function() return BB.IsDead end)

-- ============================================================
-- BigBox | shared/core.lua
-- Cria as tabelas globais e funções utilitárias usadas em tudo.
-- ============================================================

BB = BB or {}
Config = Config or {}

BB.Locales = {}
BB.Items = {}
BB.Jobs = {}
BB.Gangs = {}
BB.Sources = { items = {}, jobs = {}, gangs = {} } -- de onde veio cada registro: config / db / override

--- Traduz uma chave. Aceita argumentos estilo string.format.
--- Se a chave não existir no idioma atual, tenta pt-br e depois en.
---@param key string
function BB.T(key, ...)
    local l = BB.Locales[Config.Locale] or {}
    local s = l[key]
        or (BB.Locales['pt-br'] and BB.Locales['pt-br'][key])
        or (BB.Locales['en'] and BB.Locales['en'][key])
        or key
    if select('#', ...) > 0 then
        local ok, res = pcall(string.format, s, ...)
        return ok and res or s
    end
    return s
end

--- Cópia profunda de tabela.
function BB.Copy(t)
    if type(t) ~= 'table' then return t end
    local out = {}
    for k, v in pairs(t) do out[k] = BB.Copy(v) end
    return out
end

--- Arredonda um número.
function BB.Round(n, places)
    local m = 10 ^ (places or 0)
    return math.floor(n * m + 0.5) / m
end

--- Converte qualquer valor em inteiro seguro (nil se for NaN, infinito ou não numérico).
function BB.ToInt(v)
    v = tonumber(v)
    if not v or v ~= v or v == math.huge or v == -math.huge then return nil end
    return math.floor(v)
end

--- Decodifica JSON sem nunca estourar erro.
function BB.SafeDecode(str, fallback)
    if type(str) ~= 'string' or str == '' then return fallback end
    local ok, res = pcall(json.decode, str)
    if ok and type(res) == 'table' then return res end
    return fallback
end

--- Debug opcional (Config.Debug = true).
function BB.Debug(...)
    if Config.Debug then print('^3[bigbox:debug]^7', ...) end
end

--- Menor nível de cargo existente em um grupo.
function BB.LowestGrade(grades)
    local low
    for level in pairs(grades or {}) do
        if low == nil or level < low then low = level end
    end
    return low or 0
end

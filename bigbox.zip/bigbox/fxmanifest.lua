fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'bigbox'
author 'BigBox'
description 'BigBox - base de framework FiveM, modular e 100% configurável'
version '2.0.0'

-- Faz scripts antigos que chamam exports.bqbox:* continuarem funcionando.
-- Remova esta linha se não precisar (e NUNCA rode o bqbox antigo junto com o bigbox).
provide 'bqbox'

dependencies {
    'ox_lib',
    'oxmysql',
}

-- A ORDEM importa: core.lua primeiro, depois configs, depois locales.
shared_scripts {
    '@ox_lib/init.lua',
    'shared/core.lua',
    'config/main.lua',
    'config/items.lua',
    'config/jobs.lua',
    'locales/pt-br.lua',
    'locales/en.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/utils.lua',
    'server/db.lua',
    'server/registry.lua',
    'server/player.lua',
    'server/characters.lua',
    'server/items.lua',
    'server/drops.lua',
    'server/death.lua',
    'server/admin.lua',
    'server/commands.lua',
    'server/main.lua',
}

client_scripts {
    'client/main.lua',
    'client/preview.lua',
    'client/inventory.lua',
    'client/drops.lua',
    'client/death.lua',
    'client/admin.lua',
}

-- Inventário (NUI). Coloque os ícones dos itens em html/images/<nome_do_item>.png
ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'html/images/*.png',
}

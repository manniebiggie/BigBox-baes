-- ============================================================
-- BigBox | server/death.lua
-- Estado de morte e renascimento no hospital (Config.Death).
-- Desligue com Config.Death.enabled = false se usar outro script de ambulância.
-- ============================================================

lib.callback.register('bigbox:setDead', function(src, state)
    local p = BB.GetPlayer(src)
    if not p or type(state) ~= 'boolean' then return false end
    if not BB.RateLimit(src, 'dead', 500) then return false end

    p.metadata.isdead = state
    p.deadSince = state and os.time() or nil
    if state then p.metadata.health = nil end
    p:Sync()
    TriggerEvent('bigbox:server:deathChange', src, state)
    return true
end)

lib.callback.register('bigbox:respawn', function(src)
    local p = BB.GetPlayer(src)
    if not p or not Config.Death.enabled or not p.metadata.isdead then return false, 'respawn_wait' end

    -- O servidor confere o tempo de espera (o cliente não decide sozinho).
    local waited = os.time() - (p.deadSince or 0)
    if waited < (Config.Death.respawnTime or 0) - 3 then return false, 'respawn_wait' end

    local fee = BB.ToInt(Config.Death.fee) or 0
    if fee > 0 then
        local account = Config.Death.account
        local pay = math.min(p:GetMoney(account), fee) -- cobra só o que a pessoa tem
        local paid = 0
        if pay > 0 and p:RemoveMoney(account, pay, 'respawn', true) then paid = pay end
        p:Notify(BB.T('respawn_fee', paid), 'inform')
    end

    local x, y, z
    local ped = GetPlayerPed(src)
    if ped and ped ~= 0 then
        local c = GetEntityCoords(ped)
        x, y, z = c.x, c.y, c.z
    elseif p.position then
        x, y, z = p.position.x, p.position.y, p.position.z
    else
        x, y, z = Config.DefaultSpawn.x, Config.DefaultSpawn.y, Config.DefaultSpawn.z
    end

    p.metadata.isdead = false
    p.metadata.health = nil
    p.deadSince = nil
    p:Sync()
    TriggerEvent('bigbox:server:deathChange', src, false)
    return true, BB.NearestHospital(x, y, z)
end)

-- ============================================================
-- BigBox | server/items.lua
-- Registro de itens utilizáveis + usar / dar / descartar.
-- Para criar a ação de um item:  BB.RegisterUsable('nome', function(player) ... end)
-- Outros resources: exports.bigbox:RegisterUsable('nome', function(source) ... end)
-- ============================================================

BB.Usables = {}
local owners = {} -- [item] = resource que registrou a ação

function BB.RegisterUsable(name, cb, owner)
    BB.Usables[name] = cb
    owners[name] = owner
end

-- Se o resource que registrou a ação for parado/reiniciado, a função dele deixa de
-- existir; removemos para não dar erro ao usar o item.
AddEventHandler('onResourceStop', function(res)
    for name, owner in pairs(owners) do
        if owner == res then
            BB.Usables[name] = nil
            owners[name] = nil
        end
    end
end)

--- Distância entre dois jogadores, medida no servidor (não confia no cliente).
local function distanceBetween(a, b)
    local pa, pb = GetPlayerPed(a), GetPlayerPed(b)
    if not pa or pa == 0 or not pb or pb == 0 then return math.huge end
    local ca, cb = GetEntityCoords(pa), GetEntityCoords(pb)
    return math.sqrt((ca.x - cb.x) ^ 2 + (ca.y - cb.y) ^ 2 + (ca.z - cb.z) ^ 2)
end

-- ---------------- Callbacks chamados pelo inventário ----------------

lib.callback.register('bigbox:useItem', function(src, name)
    local p = BB.GetPlayer(src)
    if not p or type(name) ~= 'string' then return false end
    if not BB.RateLimit(src, 'use', 400) then return false, 'rate_limited' end
    if not BB.Items[name] or not p:HasItem(name, 1) then return false, 'item_not_found' end

    local cb = BB.Usables[name]
    if not cb then
        p:Notify(BB.T('inv_not_usable'), 'error')
        return false, 'inv_not_usable'
    end

    local ok, err = pcall(cb, p)
    if not ok then
        print(('^1[bigbox]^7 Erro ao usar o item "%s": %s'):format(name, tostring(err)))
        p:Notify(BB.T('item_use_error'), 'error')
        return false, 'item_use_error'
    end
    return true
end)

lib.callback.register('bigbox:giveItem', function(src, targetId, name, count)
    local p = BB.GetPlayer(src)
    targetId, count = BB.ToInt(targetId), BB.ToInt(count)
    if not p or not targetId or not count or count <= 0 or type(name) ~= 'string' then return false, 'invalid_amount' end
    if not BB.RateLimit(src, 'give', 800) then return false, 'rate_limited' end

    local t = BB.GetPlayer(targetId)
    if not t or targetId == src then return false, 'player_not_found' end
    local def = BB.Items[name]
    if not def then return false, 'invalid_item' end
    if not p:HasItem(name, count) then return false, 'item_not_found' end
    if distanceBetween(src, targetId) > (Config.Inventory.GiveDistance or 3.0) + 1.5 then return false, 'too_far' end
    if not t:CanCarry(name, count) then return false, 'target_too_heavy' end
    if not t:HasRoomFor(name) then return false, 'target_full' end

    -- Sem pausas entre a checagem e a troca: ou acontece inteira ou não acontece.
    p:RemoveItem(name, count, true)
    t:AddItem(name, count)
    p:Notify(BB.T('inv_given', count, def.label), 'success')
    BB.Log(src, 'item:give', { to = t.citizenid, item = name, count = count })
    return true
end)

--- Move um item para outro slot do inventário (troca de lugar se o destino estiver ocupado).
lib.callback.register('bigbox:moveItem', function(src, name, slot)
    local p = BB.GetPlayer(src)
    if not p or type(name) ~= 'string' then return false end
    if not BB.RateLimit(src, 'move', 100) then return false, 'rate_limited' end
    return p:MoveItem(name, slot)
end)

-- ---------------- Exemplos (edite à vontade) ----------------

local function restore(player, key, amount)
    local current = tonumber(player:GetMetadata(key)) or 100
    player:SetMetadata(key, math.min(100, current + amount))
end

BB.RegisterUsable('water', function(player)
    if player:RemoveItem('water', 1, true) then
        restore(player, 'thirst', 25) -- só guarda o valor; seu HUD/sistema de sede lê metadata.thirst
        player:Notify(BB.T('used_water'), 'success')
    end
end)

BB.RegisterUsable('bread', function(player)
    if player:RemoveItem('bread', 1, true) then
        restore(player, 'hunger', 25) -- idem: metadata.hunger
        TriggerClientEvent('bigbox:client:heal', player.source, 5)
        player:Notify(BB.T('used_bread'), 'success')
    end
end)

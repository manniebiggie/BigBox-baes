-- ============================================================
-- BigBox | server/main.lua
-- Inicialização, loops (salvamento, salário) e EXPORTS para outros resources.
-- Exemplo em outro script:  exports.bigbox:AddMoney(source, 'cash', 100, 'meu-script')
-- ============================================================

-- Sobe o banco (cria/migra tabelas e carrega os registros)
CreateThread(BB.InitDatabase)

-- Se o resource foi reiniciado com jogadores online, o servidor não tem mais os
-- personagens carregados: limpa o state bag para scripts de terceiros não se enganarem.
CreateThread(function()
    for _, id in ipairs(GetPlayers()) do
        pcall(function()
            Player(tonumber(id)).state:set('loggedIn', false, true)
            Player(tonumber(id)).state:set('isLoggedIn', false, true)
        end)
    end
end)

-- Salvamento automático (assíncrono: não trava o servidor com muitos jogadores)
CreateThread(function()
    while true do
        Wait(Config.SaveInterval * 60000)
        local n = 0
        for _, p in pairs(BB.Players) do
            if not p.unloading then
                p:Save(true)
                n = n + 1
            end
        end
        BB.Debug(('Autosave: %d jogadores'):format(n))
    end
end)

-- Guarda a posição de todos a cada 30s (ao desconectar o ped já foi removido)
CreateThread(function()
    while true do
        Wait(30000)
        for _, p in pairs(BB.Players) do p:UpdatePosition() end
    end
end)

-- Salário
CreateThread(function()
    if not Config.Paycheck.enabled then return end
    while true do
        Wait(Config.Paycheck.interval * 60000)
        for _, p in pairs(BB.Players) do
            local pay = p.job.payment or 0
            if p.job.onduty and pay > 0 and not p.unloading then
                if p:AddMoney(Config.Paycheck.account, pay, 'paycheck', true) then
                    p:Notify(BB.T('paycheck', pay), 'success')
                end
            end
        end
    end
end)

-- Salva tudo ao parar o resource
AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    for _, p in pairs(BB.Players) do p:Save() end
end)

-- ---------------- EXPORTS ----------------
-- Observação: objetos com métodos não atravessam resources de forma confiável,
-- por isso a API é feita de funções simples recebendo o "source".

local function with(src, fn, ...)
    local p = BB.Players[src]
    if not p then return false end
    return fn(p, ...)
end

exports('GetPlayerData', function(src)
    local p = BB.Players[src]
    return p and p:Public() or nil
end)
exports('IsLoggedIn', function(src) return BB.Players[src] ~= nil end)
exports('GetSourceByCitizenId', function(cid) return BB.ByCitizen[cid] end)
exports('GetCitizenId', function(src) local p = BB.Players[src]; return p and p.citizenid or nil end)
exports('IsAdmin', function(src) return BB.IsAdmin(src) end)

exports('GetMoney', function(src, t) return with(src, function(p) return p:GetMoney(t) end) or 0 end)
exports('AddMoney', function(src, t, a, r, silent) return with(src, function(p) return p:AddMoney(t, a, r, silent) end) end)
exports('RemoveMoney', function(src, t, a, r, silent) return with(src, function(p) return p:RemoveMoney(t, a, r, silent) end) end)
exports('SetMoney', function(src, t, a) return with(src, function(p) return p:SetMoney(t, a) end) end)

exports('AddItem', function(src, n, c, silent) return with(src, function(p) return p:AddItem(n, c, silent) end) end)
exports('RemoveItem', function(src, n, c, silent) return with(src, function(p) return p:RemoveItem(n, c, silent) end) end)
exports('GetItemCount', function(src, n) return with(src, function(p) return p:GetItemCount(n) end) or 0 end)
exports('HasItem', function(src, n, c) return with(src, function(p) return p:HasItem(n, c) end) end)
exports('CanCarry', function(src, n, c) return with(src, function(p) return p:CanCarry(n, c or 1) end) end)

exports('SetJob', function(src, n, g) return with(src, function(p) return p:SetJob(n, g) end) end)
exports('SetGang', function(src, n, g) return with(src, function(p) return p:SetGang(n, g) end) end)
exports('SetDuty', function(src, s) return with(src, function(p) p:SetDuty(s) return true end) end)

exports('SetMetadata', function(src, k, v) return with(src, function(p) return p:SetMetadata(k, v) end) end)
exports('GetMetadata', function(src, k) return with(src, function(p) return p:GetMetadata(k) end) end)

exports('Notify', function(src, msg, t, d) return with(src, function(p) p:Notify(msg, t, d) return true end) end)
exports('Translate', function(key, ...) return BB.T(key, ...) end)
exports('Log', function(src, action, details) BB.Log(src, action, details) return true end)

-- Para outros resources o callback recebe o "source" (e não o objeto jogador).
-- O resource que registrou é guardado: se ele for parado, a ação é removida sozinha.
exports('RegisterUsable', function(name, cb)
    BB.RegisterUsable(name, function(p) cb(p.source) end, GetInvokingResource())
end)

exports('Save', function(src) return with(src, function(p) p:Save() return true end) end)
exports('Logout', function(src) BB.Logout(src) return true end)
exports('GetAllSources', function()
    local list = {}
    for src in pairs(BB.Players) do list[#list + 1] = src end
    return list
end)

exports('GetItems', function() return BB.Items end)
exports('GetGangs', function()
    local out = {}
    for name, g in pairs(BB.Gangs) do out[name] = BB.SerializeGroup(g) end
    return out
end)
exports('GetJobs', function()
    local out = {}
    for name, g in pairs(BB.Jobs) do out[name] = BB.SerializeGroup(g) end
    return out
end)

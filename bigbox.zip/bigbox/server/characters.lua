-- ============================================================
-- BigBox | server/characters.lua
-- Login, criação, seleção, exclusão e troca de personagens.
-- ============================================================

local function getLicense(src)
    return GetPlayerIdentifierByType(src, 'license')
end

local function generateCitizenId()
    local chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    for _ = 1, 20 do
        local id = ''
        for _ = 1, 8 do
            local r = math.random(1, #chars)
            id = id .. chars:sub(r, r)
        end
        if not MySQL.scalar.await('SELECT 1 FROM bigbox_players WHERE citizenid = ?', { id }) then
            return id
        end
    end
end

-- ---------------- Validação ----------------

--- Aceita letras latinas (com acento), espaço, hífen e apóstrofo. Bloqueia emoji,
--- caracteres de controle, texto UTF-8 inválido e espaços duplicados.
--- Retorna o nome limpo ou nil.
local function cleanName(s)
    if type(s) ~= 'string' then return nil end
    s = (s:gsub('^%s+', ''))
    s = (s:gsub('%s+$', ''))
    s = (s:gsub('%s+', ' '))
    local len = utf8.len(s)
    if not len or len < 2 or len > 20 then return nil end
    for _, cp in utf8.codes(s) do
        local okChar =
            (cp >= 65 and cp <= 90) or (cp >= 97 and cp <= 122)      -- A-Z a-z
            or cp == 32 or cp == 45 or cp == 39                       -- espaço - '
            or (cp >= 0xC0 and cp <= 0x24F and cp ~= 0xD7 and cp ~= 0xF7) -- Latin acentuado
        if not okChar then return nil end
    end
    return s
end

local function daysInMonth(y, m)
    if m == 2 then return ((y % 4 == 0 and y % 100 ~= 0) or y % 400 == 0) and 29 or 28 end
    return (m == 4 or m == 6 or m == 9 or m == 11) and 30 or 31
end

--- Valida AAAA-MM-DD de verdade (31/02 não existe) e a idade mínima/máxima.
--- Retorna true, ou false + chave de erro.
local function checkBirthdate(s)
    if type(s) ~= 'string' then return false, 'char_invalid' end
    local y, m, d = s:match('^(%d%d%d%d)%-(%d%d)%-(%d%d)$')
    y, m, d = tonumber(y), tonumber(m), tonumber(d)
    if not y or m < 1 or m > 12 or d < 1 or d > daysInMonth(y, m) then return false, 'char_invalid' end

    local now = os.date('*t')
    local age = now.year - y
    if now.month < m or (now.month == m and now.day < d) then age = age - 1 end
    if age < (Config.MinAge or 0) or age > (Config.MaxAge or 150) then return false, 'char_age' end
    return true
end

-- ---------------- Callbacks ----------------

lib.callback.register('bigbox:getCharacters', function(src)
    if not BB.WaitReady() then return { chars = {}, max = Config.MaxCharacters, canDelete = false } end
    local license = getLicense(src)
    if not license then return { chars = {}, max = Config.MaxCharacters, canDelete = false } end
    local rows = MySQL.query.await(
        'SELECT citizenid, firstname, lastname, birthdate, gender, job FROM bigbox_players WHERE license = ? ORDER BY last_seen DESC',
        { license }) or {}
    local chars = {}
    for _, r in ipairs(rows) do
        local job = BB.SafeDecode(r.job, {})
        local def = BB.Jobs[job.name or Config.DefaultJob]
        chars[#chars + 1] = {
            citizenid = r.citizenid,
            firstname = r.firstname,
            lastname = r.lastname,
            birthdate = r.birthdate,
            gender = r.gender,
            job = def and def.label or '?',
        }
    end
    return { chars = chars, max = Config.MaxCharacters, canDelete = Config.AllowDeleteCharacter }
end)

local creating = {} -- trava: evita criar vários personagens ao mesmo tempo (burlar o limite)

lib.callback.register('bigbox:createCharacter', function(src, data)
    if not BB.WaitReady() then return false, 'char_error' end
    local license = getLicense(src)
    if not license or BB.Players[src] or type(data) ~= 'table' then return false, 'char_invalid' end
    if creating[src] or not BB.RateLimit(src, 'create', 1500) then return false, 'rate_limited' end

    local first, last = cleanName(data.firstname), cleanName(data.lastname)
    local gender = BB.ToInt(data.gender)
    if not first or not last or (gender ~= 0 and gender ~= 1) then return false, 'char_invalid' end
    local okDate, dateErr = checkBirthdate(data.birthdate)
    if not okDate then return false, dateErr end

    creating[src] = true
    local ok, result, err = pcall(function()
        local count = MySQL.scalar.await('SELECT COUNT(*) FROM bigbox_players WHERE license = ?', { license }) or 0
        if count >= Config.MaxCharacters then return false, 'char_limit' end

        local cid = generateCitizenId()
        if not cid then return false, 'char_error' end

        local money = {}
        for mtype, cfg in pairs(Config.Money) do money[mtype] = cfg.start or 0 end

        local id = MySQL.insert.await(
            'INSERT INTO bigbox_players (citizenid, license, firstname, lastname, birthdate, gender, money, job, gang, inventory, metadata, position) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            {
                cid, license, first, last, data.birthdate, gender,
                json.encode(money),
                json.encode({ name = Config.DefaultJob, grade = Config.DefaultJobGrade, onduty = true }),
                json.encode({ name = Config.DefaultGang, grade = Config.DefaultGangGrade }),
                json.encode({}), json.encode({}), json.encode({}),
            })
        if id == nil then return false, 'char_error' end
        return cid
    end)
    creating[src] = nil

    if not ok then
        print('^1[bigbox]^7 Erro ao criar personagem: ' .. tostring(result))
        return false, 'char_error'
    end
    if result then BB.Log(src, 'char:create', { citizenid = result }) end
    return result, err
end)

--- Posição do hospital mais próximo de (x, y, z).
function BB.NearestHospital(x, y, z)
    local best, bestDist
    for _, h in ipairs(Config.Death.hospitals or {}) do
        local dx, dy, dz = h.x - x, h.y - y, h.z - z
        local dist = dx * dx + dy * dy + dz * dz
        if not bestDist or dist < bestDist then best, bestDist = h, dist end
    end
    best = best or Config.DefaultSpawn
    return { x = best.x, y = best.y, z = best.z, w = best.w }
end

lib.callback.register('bigbox:selectCharacter', function(src, citizenid)
    if not BB.WaitReady() then return false end
    local license = getLicense(src)
    if not license or BB.Players[src] or BB.Loading[src] or type(citizenid) ~= 'string' or #citizenid > 11 then
        return false
    end
    if BB.ByCitizen[citizenid] then return false end -- já está logado

    BB.Loading[src] = true
    local ok, p = pcall(BB.LoadPlayer, src, citizenid, license)
    BB.Loading[src] = nil
    if not ok then
        print('^1[bigbox]^7 Erro ao carregar personagem: ' .. tostring(p))
        return false
    end
    if not p then return false end

    local isNew = not p.position or p.position.x == nil
    local pos
    if isNew then
        pos = { x = Config.DefaultSpawn.x, y = Config.DefaultSpawn.y, z = Config.DefaultSpawn.z, w = Config.DefaultSpawn.w }
    elseif p.metadata.isdead and Config.Death.enabled then
        -- Deslogou morto: renasce no hospital mais próximo (evita fugir da morte relogando).
        pos = BB.NearestHospital(p.position.x, p.position.y, p.position.z)
        p.metadata.isdead = false
        p.metadata.health = nil
    else
        pos = p.position
    end

    p:Sync()
    TriggerEvent('bigbox:server:playerLoaded', src, p.citizenid, isNew)
    return {
        position = pos,
        gender = p.charinfo.gender,
        isNew = isNew,
        name = p.charinfo.firstname,
        health = p.metadata.health,
        armor = p.metadata.armor,
    }
end)

lib.callback.register('bigbox:deleteCharacter', function(src, citizenid)
    if not Config.AllowDeleteCharacter or BB.Players[src] or type(citizenid) ~= 'string' then return false end
    if not BB.RateLimit(src, 'delete', 1500) then return false end
    local license = getLicense(src)
    if not license then return false end
    local affected = MySQL.update.await('DELETE FROM bigbox_players WHERE citizenid = ? AND license = ?', { citizenid, license })
    if (affected or 0) > 0 then
        BB.Log(src, 'char:delete', { citizenid = citizenid })
        return true
    end
    return false
end)

-- Troca de personagem (salva e volta ao menu)
function BB.Logout(src)
    if not BB.Players[src] then return end
    BB.UnloadPlayer(src, true)
    TriggerClientEvent('bigbox:client:openCharacterMenu', src)
end

AddEventHandler('playerDropped', function()
    local src = source
    BB.Loading[src] = nil
    creating[src] = nil
    if BB.Players[src] then BB.UnloadPlayer(src, true) end
end)

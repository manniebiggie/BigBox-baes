-- ============================================================
-- BigBox | server/commands.lua
-- Comandos. Os de admin exigem a permissão Config.AdminAce.
-- ============================================================

--- Responde a quem executou (notificação no jogo ou print no console).
local function reply(source, msg, ntype)
    if source == 0 then
        print('[bigbox] ' .. msg)
    else
        TriggerClientEvent('bigbox:client:notify', source, msg, ntype or 'inform')
    end
end

--- Executa uma ação admin sobre o jogador alvo e avisa o resultado.
local function run(source, targetId, action, data)
    local p = BB.GetPlayer(targetId)
    if not p then return reply(source, BB.T('player_not_found'), 'error') end
    local ok, err = BB.AdminAction(source, p, action, data)
    reply(source, ok and BB.T('cmd_done') or BB.T(err or 'admin_error'), ok and 'success' or 'error')
end

lib.addCommand('setjob', {
    help = BB.T('cmd_setjob'),
    params = {
        { name = 'id', type = 'playerId' },
        { name = 'job', type = 'string' },
        { name = 'grade', type = 'number', optional = true },
    },
    restricted = Config.AdminAce,
}, function(source, args)
    run(source, args.id, 'setjob', { job = args.job, grade = args.grade })
end)

lib.addCommand('setgang', {
    help = BB.T('cmd_setgang'),
    params = {
        { name = 'id', type = 'playerId' },
        { name = 'gang', type = 'string' },
        { name = 'grade', type = 'number', optional = true },
    },
    restricted = Config.AdminAce,
}, function(source, args)
    run(source, args.id, 'setgang', { gang = args.gang, grade = args.grade })
end)

lib.addCommand('givemoney', {
    help = BB.T('cmd_givemoney'),
    params = {
        { name = 'id', type = 'playerId' },
        { name = 'tipo', type = 'string', help = 'cash, bank...' },
        { name = 'valor', type = 'number' },
    },
    restricted = Config.AdminAce,
}, function(source, args)
    run(source, args.id, 'givemoney', { type = args.tipo, amount = args.valor })
end)

lib.addCommand('removemoney', {
    help = BB.T('cmd_removemoney'),
    params = {
        { name = 'id', type = 'playerId' },
        { name = 'tipo', type = 'string', help = 'cash, bank...' },
        { name = 'valor', type = 'number' },
    },
    restricted = Config.AdminAce,
}, function(source, args)
    run(source, args.id, 'removemoney', { type = args.tipo, amount = args.valor })
end)

lib.addCommand('setmoney', {
    help = BB.T('cmd_setmoney'),
    params = {
        { name = 'id', type = 'playerId' },
        { name = 'tipo', type = 'string', help = 'cash, bank...' },
        { name = 'valor', type = 'number' },
    },
    restricted = Config.AdminAce,
}, function(source, args)
    run(source, args.id, 'setmoney', { type = args.tipo, amount = args.valor })
end)

lib.addCommand('giveitem', {
    help = BB.T('cmd_giveitem'),
    params = {
        { name = 'id', type = 'playerId' },
        { name = 'item', type = 'string' },
        { name = 'qtd', type = 'number', optional = true },
    },
    restricted = Config.AdminAce,
}, function(source, args)
    run(source, args.id, 'giveitem', { item = args.item, amount = args.qtd or 1 })
end)

lib.addCommand('removeitem', {
    help = BB.T('cmd_removeitem'),
    params = {
        { name = 'id', type = 'playerId' },
        { name = 'item', type = 'string' },
        { name = 'qtd', type = 'number', optional = true },
    },
    restricted = Config.AdminAce,
}, function(source, args)
    run(source, args.id, 'removeitem', { item = args.item, amount = args.qtd or 1 })
end)

lib.addCommand('revive', {
    help = BB.T('cmd_revive'),
    params = {
        { name = 'id', type = 'playerId', optional = true },
    },
    restricted = Config.AdminAce,
}, function(source, args)
    local target = args.id or source
    if target == 0 then return reply(source, BB.T('player_not_found'), 'error') end
    run(source, target, 'revive')
end)

-- Comandos livres para todos os jogadores

lib.addCommand('duty', { help = BB.T('cmd_duty') }, function(source)
    local p = BB.GetPlayer(source)
    if p then p:SetDuty(not p.job.onduty) end
end)

lib.addCommand('trocarchar', { help = BB.T('cmd_switchchar') }, function(source)
    if not BB.RateLimit(source, 'switch', 3000) then return end
    BB.Logout(source)
end)

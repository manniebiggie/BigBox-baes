-- ============================================================
-- BigBox | server/admin.lua
-- Callbacks do painel admin (/bigadmin) e ações sobre jogadores.
-- Toda ação checa permissão no servidor; o cliente nunca é confiável.
-- ============================================================

local function validKey(s)
    return type(s) == 'string' and #s >= 2 and #s <= 50 and s:match('^[%l%d_]+$') ~= nil
end

local function cleanText(s, max)
    if type(s) ~= 'string' then return nil end
    s = (s:gsub('^%s+', ''))
    s = (s:gsub('%s+$', ''))
    if s == '' or #s > (max or 60) then return nil end
    return s
end

lib.callback.register('bigbox:admin:isAdmin', function(src)
    return BB.IsAdmin(src)
end)

lib.callback.register('bigbox:admin:getRegistry', function(src)
    if not BB.IsAdmin(src) then return nil end
    local jobs, gangs, money = {}, {}, {}
    for name, g in pairs(BB.Jobs) do jobs[name] = BB.SerializeGroup(g) end
    for name, g in pairs(BB.Gangs) do gangs[name] = BB.SerializeGroup(g) end
    for key, cfg in pairs(Config.Money) do money[#money + 1] = { key = key, label = cfg.label } end
    table.sort(money, function(a, b) return a.key < b.key end)
    return { items = BB.Items, jobs = jobs, gangs = gangs, sources = BB.Sources, money = money }
end)

lib.callback.register('bigbox:admin:reload', function(src)
    if not BB.IsAdmin(src) then return false end
    local ok = BB.LoadRegistry()
    BB.RefreshAllPlayers()
    BB.Log(src, 'admin:reload', '')
    return ok
end)

-- ---------------- Itens ----------------

lib.callback.register('bigbox:admin:saveItem', function(src, name, data)
    if not BB.IsAdmin(src) then return false, 'no_permission' end
    if not validKey(name) or type(data) ~= 'table' then return false, 'admin_error' end

    local label = cleanText(data.label)
    local weight = BB.ToInt(data.weight) or -1
    if not label or weight < 0 or weight > 1000000 then return false, 'admin_error' end

    local ok = BB.SaveItem(name, {
        label = label,
        weight = weight,
        usable = data.usable and true or false,
        description = cleanText(data.description, 255) or '',
    })
    if not ok then return false, 'admin_error' end
    BB.Log(src, 'admin:saveItem', name)
    return true
end)

lib.callback.register('bigbox:admin:deleteItem', function(src, name)
    if not BB.IsAdmin(src) then return false, 'no_permission' end
    if not validKey(name) then return false, 'admin_error' end
    local source = BB.Sources.items[name]
    if not source then return false, 'admin_error' end
    -- Item que só existe no config.lua não tem o que apagar no banco.
    if source == 'config' then return false, 'admin_config_only' end
    if not BB.DeleteItem(name) then return false, 'admin_error' end
    BB.Log(src, 'admin:deleteItem', name)
    return true
end)

-- ---------------- Empregos / Gangues ----------------

local function validGrades(list)
    if type(list) ~= 'table' or #list == 0 then return nil end
    local out, seen = {}, {}
    for _, g in ipairs(list) do
        local level = BB.ToInt(g.grade) or -1
        local name = cleanText(g.name)
        local pay = BB.ToInt(g.payment) or -1
        if level < 0 or level > 50 or seen[level] or not name or pay < 0 or pay > 1000000 then return nil end
        seen[level] = true
        out[#out + 1] = { grade = level, name = name, payment = pay, boss = g.boss and true or false }
    end
    return out
end

lib.callback.register('bigbox:admin:saveGroup', function(src, kind, name, data)
    if not BB.IsAdmin(src) then return false, 'no_permission' end
    if (kind ~= 'job' and kind ~= 'gang') or not validKey(name) or type(data) ~= 'table' then
        return false, 'admin_error'
    end

    local label = cleanText(data.label)
    local gtype = cleanText(data.type, 30) or (kind == 'job' and 'civil' or 'gang')
    local grades = validGrades(data.grades)
    if not label or not grades then return false, 'admin_error' end

    if not BB.SaveGroup(kind, name, { label = label, type = gtype, grades = grades }) then return false, 'admin_error' end
    BB.Log(src, 'admin:saveGroup', ('%s %s'):format(kind, name))
    return true
end)

lib.callback.register('bigbox:admin:deleteGroup', function(src, kind, name)
    if not BB.IsAdmin(src) then return false, 'no_permission' end
    if (kind ~= 'job' and kind ~= 'gang') or not validKey(name) then return false, 'admin_error' end
    local list = kind == 'job' and BB.Sources.jobs or BB.Sources.gangs
    if not list[name] then return false, 'admin_error' end
    if list[name] == 'config' then return false, 'admin_config_only' end
    if not BB.DeleteGroup(kind, name) then return false, 'admin_error' end
    BB.Log(src, 'admin:deleteGroup', ('%s %s'):format(kind, name))
    return true
end)

-- ---------------- Jogadores ----------------

--- Aplica uma ação administrativa a um jogador. Usada pelo painel e pelos comandos.
--- Retorna true, ou false + chave de erro.
function BB.AdminAction(admin, p, action, data)
    data = type(data) == 'table' and data or {}
    local ok, err = false, 'admin_error'

    if action == 'setjob' then
        if type(data.job) ~= 'string' then return false, 'invalid_job' end
        ok, err = p:SetJob(data.job, data.grade), 'invalid_job'
    elseif action == 'setgang' then
        if type(data.gang) ~= 'string' then return false, 'invalid_job' end
        ok, err = p:SetGang(data.gang, data.grade), 'invalid_job'
    elseif action == 'givemoney' then
        ok, err = p:AddMoney(data.type, data.amount, 'admin:' .. tostring(admin))
    elseif action == 'removemoney' then
        ok, err = p:RemoveMoney(data.type, data.amount, 'admin:' .. tostring(admin))
    elseif action == 'setmoney' then
        ok, err = p:SetMoney(data.type, data.amount, 'admin:' .. tostring(admin))
    elseif action == 'giveitem' then
        if type(data.item) ~= 'string' then return false, 'invalid_item' end
        ok, err = p:AddItem(data.item, data.amount or 1)
    elseif action == 'removeitem' then
        if type(data.item) ~= 'string' then return false, 'invalid_item' end
        ok, err = p:RemoveItem(data.item, data.amount or 1)
    elseif action == 'revive' then
        TriggerClientEvent('bigbox:client:revive', p.source)
        ok = true
    elseif action == 'logout' then
        local target = p.source
        CreateThread(function() BB.Logout(target) end)
        ok = true
    else
        return false, 'admin_error'
    end

    if ok then
        BB.Log(admin, 'admin:' .. action, { target = p.citizenid, data = data })
        return true
    end
    return false, err or 'admin_error'
end

lib.callback.register('bigbox:admin:getPlayers', function(src)
    if not BB.IsAdmin(src) then return nil end
    local list = {}
    for id, p in pairs(BB.Players) do
        list[#list + 1] = {
            source = id,
            name = GetPlayerName(id) or '?',
            citizenid = p.citizenid,
            charname = ('%s %s'):format(p.charinfo.firstname, p.charinfo.lastname),
            job = ('%s (%s)'):format(p.job.label, p.job.grade.name),
            gang = p.gang.label,
        }
    end
    table.sort(list, function(a, b) return a.source < b.source end)
    return list
end)

lib.callback.register('bigbox:admin:playerAction', function(src, targetId, action, data)
    if not BB.IsAdmin(src) then return false, 'no_permission' end
    if type(action) ~= 'string' then return false, 'admin_error' end
    targetId = BB.ToInt(targetId)
    local p = targetId and BB.GetPlayer(targetId)
    if not p then return false, 'player_not_found' end
    return BB.AdminAction(src, p, action, data)
end)

-- ============================================================
-- BigBox | server/player.lua
-- Objeto Jogador: dinheiro, itens, emprego, gangue, metadata.
-- Outros resources devem usar os exports (veja server/main.lua).
-- ============================================================

BB.Players = BB.Players or {}   -- [source] = Player
BB.ByCitizen = {}               -- [citizenid] = source
BB.Loading = {}                 -- [source] = true enquanto um personagem está sendo carregado

local PlayerObj = {}
PlayerObj.__index = PlayerObj

-- ---------------- Helpers ----------------

local function buildGroup(registry, defaultName, name, grade)
    local g = registry[name]
    if not g then name = defaultName; g = registry[name] end
    local data = g.grades[grade]
    if not data then
        grade = BB.LowestGrade(g.grades)
        data = g.grades[grade] or { name = '?', payment = 0 }
    end
    return {
        name = name,
        label = g.label,
        type = g.type,
        grade = { level = grade, name = data.name },
        payment = data.payment or 0,
        isboss = data.boss and true or false,
    }
end

local function buildJob(name, grade, onduty)
    local j = buildGroup(BB.Jobs, Config.DefaultJob, name, grade)
    j.onduty = onduty ~= false
    return j
end

local function buildGang(name, grade)
    return buildGroup(BB.Gangs, Config.DefaultGang, name, grade)
end

--- Notifica só se a opção da config estiver ligada e não for silencioso.
local function shouldNotify(kind, silent)
    return not silent and Config.Notify[kind] ~= false
end

-- ---------------- Criação ----------------

function BB.CreatePlayerObject(src, row)
    local self = setmetatable({}, PlayerObj)
    self.source = src
    self.license = row.license
    self.citizenid = row.citizenid
    self.charinfo = { firstname = row.firstname, lastname = row.lastname, birthdate = row.birthdate, gender = row.gender }

    self.money = {}
    local savedMoney = BB.SafeDecode(row.money, {})
    for mtype in pairs(Config.Money) do
        self.money[mtype] = BB.ToInt(savedMoney[mtype]) or 0
    end

    self.inventory = {}
    for name, count in pairs(BB.SafeDecode(row.inventory, {})) do
        count = BB.ToInt(count)
        if count and count > 0 then self.inventory[name] = count end
    end

    self.metadata = BB.SafeDecode(row.metadata, {})

    local j = BB.SafeDecode(row.job, {})
    self.job = buildJob(j.name or Config.DefaultJob, j.grade or Config.DefaultJobGrade, j.onduty)
    local g = BB.SafeDecode(row.gang, {})
    self.gang = buildGang(g.name or Config.DefaultGang, g.grade or Config.DefaultGangGrade)

    self.position = BB.SafeDecode(row.position, nil)
    return self
end

-- ---------------- Dados públicos / sync ----------------

function PlayerObj:GetWeight()
    local total = 0
    for name, count in pairs(self.inventory) do
        local it = BB.Items[name]
        total = total + ((it and it.weight or 0) * count)
    end
    return total
end

function PlayerObj:Public()
    local inv = {}
    local slots, slotCount = self:NormalizeSlots()
    for name, count in pairs(self.inventory) do
        local it = BB.Items[name] or { label = name, weight = 0, description = '', usable = false }
        inv[#inv + 1] = {
            name = name, label = it.label, count = count, slot = slots[name],
            weight = it.weight or 0, description = it.description or '',
            -- usável se marcado na config OU se algum script registrou uma ação para ele
            usable = (it.usable or (BB.Usables and BB.Usables[name] ~= nil)) and true or false,
        }
    end
    table.sort(inv, function(a, b) return a.slot < b.slot end)

    return {
        source = self.source,
        citizenid = self.citizenid,
        charinfo = self.charinfo,
        money = self.money,
        job = self.job,
        gang = self.gang,
        inventory = inv,
        slots = slotCount,
        metadata = self.metadata,
        weight = self:GetWeight(),
        maxWeight = Config.Inventory.MaxWeight,
    }
end

function PlayerObj:Sync()
    TriggerClientEvent('bigbox:client:setPlayerData', self.source, self:Public())
end

function PlayerObj:Notify(msg, ntype, duration)
    TriggerClientEvent('bigbox:client:notify', self.source, msg, ntype or 'inform', duration)
end

-- ---------------- Dinheiro ----------------

function PlayerObj:GetMoney(mtype) return self.money[mtype] or 0 end

--- Adiciona dinheiro. Retorna true, ou false + motivo.
---@param silent boolean|nil não mostrar notificação
function PlayerObj:AddMoney(mtype, amount, reason, silent)
    amount = BB.ToInt(amount)
    if not amount or amount <= 0 or not Config.Money[mtype] then return false, 'invalid_amount' end
    if self.money[mtype] + amount > (Config.MaxMoney or 2000000000) then return false, 'money_cap' end
    self.money[mtype] = self.money[mtype] + amount
    self:Sync()
    if shouldNotify('money', silent) then
        self:Notify(BB.T('money_added', amount, Config.Money[mtype].label), 'success')
    end
    TriggerEvent('bigbox:server:moneyChange', self.source, mtype, amount, 'add', reason or 'unknown')
    if amount >= (Config.Logs.moneyThreshold or math.huge) then
        BB.Log(self.source, 'money:add', { citizenid = self.citizenid, type = mtype, amount = amount, reason = reason })
    end
    return true
end

function PlayerObj:RemoveMoney(mtype, amount, reason, silent)
    amount = BB.ToInt(amount)
    if not amount or amount <= 0 or not Config.Money[mtype] then return false, 'invalid_amount' end
    if self.money[mtype] < amount then return false, 'not_enough_money' end
    self.money[mtype] = self.money[mtype] - amount
    self:Sync()
    if shouldNotify('money', silent) then
        self:Notify(BB.T('money_removed', amount, Config.Money[mtype].label), 'inform')
    end
    TriggerEvent('bigbox:server:moneyChange', self.source, mtype, amount, 'remove', reason or 'unknown')
    if amount >= (Config.Logs.moneyThreshold or math.huge) then
        BB.Log(self.source, 'money:remove', { citizenid = self.citizenid, type = mtype, amount = amount, reason = reason })
    end
    return true
end

function PlayerObj:SetMoney(mtype, amount, reason)
    amount = BB.ToInt(amount)
    if not amount or amount < 0 or amount > (Config.MaxMoney or 2000000000) or not Config.Money[mtype] then
        return false, 'invalid_amount'
    end
    local old = self.money[mtype]
    self.money[mtype] = amount
    self:Sync()
    TriggerEvent('bigbox:server:moneyChange', self.source, mtype, amount, 'set', reason or 'unknown')
    BB.Log(self.source, 'money:set', { citizenid = self.citizenid, type = mtype, from = old, to = amount, reason = reason })
    return true
end

-- ---------------- Itens ----------------

function PlayerObj:GetItemCount(name) return self.inventory[name] or 0 end
function PlayerObj:HasItem(name, count) return self:GetItemCount(name) >= (count or 1) end

-- ---------------- Slots ----------------
-- Cada item ocupa um slot (uma pilha por item). O mapa item -> slot fica em metadata.slots.

--- Garante que todo item tenha um slot válido e único (e limpa slots de itens que sumiram).
function PlayerObj:NormalizeSlots()
    local slots = self.metadata.slots
    if type(slots) ~= 'table' then slots = {}; self.metadata.slots = slots end
    local max = Config.Inventory.Slots or 25
    local used = {}
    for name, slot in pairs(slots) do
        slot = BB.ToInt(slot)
        if not self.inventory[name] or not slot or slot < 1 or used[slot] then
            slots[name] = nil
        else
            slots[name] = slot
            used[slot] = name
        end
    end
    local pending = {}
    for name in pairs(self.inventory) do
        if not slots[name] then pending[#pending + 1] = name end
    end
    table.sort(pending)
    local free = 1
    for _, name in ipairs(pending) do
        while used[free] do free = free + 1 end
        slots[name] = free
        used[free] = name
    end
    local highest = max
    for slot in pairs(used) do
        if slot > highest then highest = slot end
    end
    return slots, highest
end

--- Tem espaço para uma pilha nova deste item? (pilha existente sempre tem)
function PlayerObj:HasRoomFor(name)
    if self.inventory[name] then return true end
    local stacks = 0
    for _ in pairs(self.inventory) do stacks = stacks + 1 end
    return stacks < (Config.Inventory.Slots or 25)
end

--- Move um item para o slot indicado; se houver outro item lá, os dois trocam de lugar.
function PlayerObj:MoveItem(name, toSlot)
    toSlot = BB.ToInt(toSlot)
    local max = Config.Inventory.Slots or 25
    if not self.inventory[name] or not toSlot or toSlot < 1 or toSlot > max then return false end
    local slots = self:NormalizeSlots()
    local from = slots[name]
    for other, s in pairs(slots) do
        if s == toSlot and other ~= name then slots[other] = from end
    end
    slots[name] = toSlot
    self:Sync()
    return true
end

function PlayerObj:CanCarry(name, count)
    local it = BB.Items[name]
    if not it then return false end
    return self:GetWeight() + (it.weight or 0) * count <= Config.Inventory.MaxWeight
end

function PlayerObj:AddItem(name, count, silent)
    count = BB.ToInt(count)
    local it = BB.Items[name]
    if not count or count <= 0 or count > 1000000 or not it then return false, 'invalid_item' end
    if not self:CanCarry(name, count) then
        if not silent then self:Notify(BB.T('too_heavy'), 'error') end
        return false, 'too_heavy'
    end
    if not self:HasRoomFor(name) then
        if not silent then self:Notify(BB.T('inv_full'), 'error') end
        return false, 'inv_full'
    end
    self.inventory[name] = (self.inventory[name] or 0) + count
    self:Sync()
    if shouldNotify('items', silent) then
        self:Notify(BB.T('item_added', count, it.label), 'success')
    end
    TriggerEvent('bigbox:server:itemChange', self.source, name, count, 'add')
    return true
end

function PlayerObj:RemoveItem(name, count, silent)
    count = BB.ToInt(count)
    if not count or count <= 0 then return false, 'invalid_amount' end
    if not self:HasItem(name, count) then return false, 'item_not_found' end
    self.inventory[name] = self.inventory[name] - count
    if self.inventory[name] <= 0 then self.inventory[name] = nil end
    local it = BB.Items[name]
    self:Sync()
    if shouldNotify('items', silent) then
        self:Notify(BB.T('item_removed', count, it and it.label or name), 'inform')
    end
    TriggerEvent('bigbox:server:itemChange', self.source, name, count, 'remove')
    return true
end

-- ---------------- Emprego / Gangue ----------------

function PlayerObj:SetJob(name, grade)
    local def = BB.Jobs[name]
    if not def then return false end
    grade = BB.ToInt(grade) or BB.LowestGrade(def.grades)
    if not def.grades[grade] then return false end
    local old = self.job
    self.job = buildJob(name, grade, true)
    self:Sync()
    self:Notify(BB.T('job_set', self.job.label, self.job.grade.name), 'inform')
    TriggerEvent('bigbox:server:jobUpdated', self.source, self.job, old)
    return true
end

function PlayerObj:SetGang(name, grade)
    local def = BB.Gangs[name]
    if not def then return false end
    grade = BB.ToInt(grade) or BB.LowestGrade(def.grades)
    if not def.grades[grade] then return false end
    local old = self.gang
    self.gang = buildGang(name, grade)
    self:Sync()
    self:Notify(BB.T('gang_set', self.gang.label, self.gang.grade.name), 'inform')
    TriggerEvent('bigbox:server:gangUpdated', self.source, self.gang, old)
    return true
end

function PlayerObj:SetDuty(state)
    self.job.onduty = state and true or false
    self:Sync()
    self:Notify(BB.T(self.job.onduty and 'duty_on' or 'duty_off'), 'inform')
    TriggerEvent('bigbox:server:dutyChange', self.source, self.job.onduty)
end

--- Recalcula emprego/gangue (usado quando o admin edita cargos).
function PlayerObj:RefreshGroups()
    self.job = buildJob(self.job.name, self.job.grade.level, self.job.onduty)
    self.gang = buildGang(self.gang.name, self.gang.grade.level)
end

-- ---------------- Metadata ----------------

function PlayerObj:SetMetadata(key, value)
    if type(key) ~= 'string' or key == '' then return false end
    self.metadata[key] = value
    self:Sync()
    return true
end

function PlayerObj:GetMetadata(key) return self.metadata[key] end

-- ---------------- Salvar ----------------

--- Atualiza posição, vida e colete em memória (ao desconectar o ped já não existe,
--- por isso o servidor chama isto periodicamente - veja server/main.lua).
function PlayerObj:UpdatePosition()
    local ped = GetPlayerPed(self.source)
    if ped and ped ~= 0 then
        local c = GetEntityCoords(ped)
        if c.x ~= 0.0 or c.y ~= 0.0 then
            self.position = { x = c.x, y = c.y, z = c.z, w = GetEntityHeading(ped) }
            if not self.metadata.isdead then
                local hp = GetEntityHealth(ped)
                if hp and hp > 0 then self.metadata.health = hp end
                self.metadata.armor = GetPedArmour(ped)
            end
        end
    end
end

--- Salva o personagem. Com async = true não bloqueia (usado no autosave).
function PlayerObj:Save(async)
    self:UpdatePosition()
    local query = 'UPDATE bigbox_players SET money = ?, job = ?, gang = ?, inventory = ?, metadata = ?, position = ? WHERE citizenid = ?'
    local params = {
        json.encode(self.money),
        json.encode({ name = self.job.name, grade = self.job.grade.level, onduty = self.job.onduty }),
        json.encode({ name = self.gang.name, grade = self.gang.grade.level }),
        json.encode(self.inventory),
        json.encode(self.metadata),
        json.encode(self.position or {}),
        self.citizenid,
    }
    if async then MySQL.update(query, params) else MySQL.update.await(query, params) end
end

-- ---------------- Gerenciamento global ----------------

function BB.GetPlayer(src) return BB.Players[src] end

function BB.GetPlayerByCitizenId(cid)
    local src = BB.ByCitizen[cid]
    return src and BB.Players[src] or nil
end

function BB.LoadPlayer(src, citizenid, license)
    local row = MySQL.single.await('SELECT * FROM bigbox_players WHERE citizenid = ? AND license = ?', { citizenid, license })
    if not row then return nil end

    -- O jogador pode ter saído enquanto a consulta rodava. Sem esta checagem ele ficaria
    -- "fantasma" em BB.Players e o próximo jogador a receber o mesmo ID herdaria o personagem.
    if not GetPlayerName(src) then return nil end
    if BB.Players[src] or BB.ByCitizen[citizenid] then return nil end

    local p = BB.CreatePlayerObject(src, row)
    BB.Players[src] = p
    BB.ByCitizen[citizenid] = src
    Player(src).state:set('loggedIn', true, true)
    Player(src).state:set('isLoggedIn', true, true) -- compat com scripts de QBCore
    Player(src).state:set('citizenid', citizenid, true)
    return p
end

function BB.UnloadPlayer(src, save)
    local p = BB.Players[src]
    if not p or p.unloading then return end
    p.unloading = true
    if save then p:Save() end
    TriggerEvent('bigbox:server:playerUnloaded', src, p.citizenid)
    BB.ByCitizen[p.citizenid] = nil
    BB.Players[src] = nil
    -- O state bag pode já não existir se o jogador caiu; por isso o pcall.
    pcall(function()
        Player(src).state:set('loggedIn', false, true)
        Player(src).state:set('isLoggedIn', false, true)
    end)
end

function BB.RefreshAllPlayers()
    for _, p in pairs(BB.Players) do
        p:RefreshGroups()
        p:Sync()
    end
end

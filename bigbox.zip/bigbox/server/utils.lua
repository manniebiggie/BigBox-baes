-- ============================================================
-- BigBox | server/utils.lua
-- Funções de apoio do servidor: permissão admin, limite de uso e logs.
-- ============================================================

BB.Players = BB.Players or {}   -- [source] = Player (preenchido em player.lua)

--- Verifica se o jogador é admin (ACE). O console (source 0) sempre é.
function BB.IsAdmin(src)
    if src == 0 then return true end
    if not src then return false end
    return IsPlayerAceAllowed(src, Config.AdminAce) or IsPlayerAceAllowed(src, 'command')
end

-- ---------------- Limite de uso (anti-spam de callbacks) ----------------

local lastCall = {} -- [source][chave] = tempo

--- Retorna true se a ação pode ser executada agora; false se foi chamada rápido demais.
---@param ms number intervalo mínimo entre chamadas
function BB.RateLimit(src, key, ms)
    local now = GetGameTimer()
    local t = lastCall[src]
    if not t then t = {}; lastCall[src] = t end
    if t[key] and now - t[key] < ms then return false end
    t[key] = now
    return true
end

AddEventHandler('playerDropped', function()
    lastCall[source] = nil
end)

-- ---------------- Logs ----------------

--- Registra uma ação no console e/ou na tabela bigbox_logs.
---@param src number|nil quem fez (nil/0 = sistema)
---@param action string ex.: 'admin:setjob'
---@param details any texto ou tabela
function BB.Log(src, action, details)
    if type(details) == 'table' then details = json.encode(details) end
    details = details and tostring(details) or ''

    local license, citizenid
    if src and src > 0 then
        license = GetPlayerIdentifierByType(src, 'license')
        local p = BB.Players[src]
        citizenid = p and p.citizenid or nil
    end

    if Config.Logs.console then
        print(('^3[bigbox:log]^7 %s (%s) %s -> %s'):format(
            src and src > 0 and GetPlayerName(src) or 'sistema', src or 0, action, details))
    end
    if Config.Logs.database and BB.Ready then
        MySQL.insert('INSERT INTO bigbox_logs (license, citizenid, action, details) VALUES (?, ?, ?, ?)',
            { license, citizenid, action, details })
    end
end

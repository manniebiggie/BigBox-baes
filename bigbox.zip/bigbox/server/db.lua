-- ============================================================
-- BigBox | server/db.lua
-- Cria as tabelas na primeira inicialização e migra as tabelas
-- antigas (bqbox_*) para o novo nome (bigbox_*) sem perder dados.
-- ============================================================

BB.Ready = false

local CHARSET = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'

local function tableExists(name)
    return MySQL.scalar.await(
        'SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ? LIMIT 1',
        { name }) ~= nil
end

--- Renomeia bqbox_players -> bigbox_players etc. (só se a antiga existir e a nova não).
local function migrateLegacyTables()
    for _, suffix in ipairs({ 'players', 'items', 'jobs', 'gangs' }) do
        local old, new = 'bqbox_' .. suffix, 'bigbox_' .. suffix
        if tableExists(old) and not tableExists(new) then
            MySQL.query.await(('RENAME TABLE `%s` TO `%s`'):format(old, new))
            print(('^2[bigbox]^7 Tabela migrada: %s -> %s'):format(old, new))
        end
    end
end

local function createTables()
    MySQL.query.await(([[
        CREATE TABLE IF NOT EXISTS `bigbox_players` (
            `citizenid` VARCHAR(11) NOT NULL,
            `license` VARCHAR(60) NOT NULL,
            `firstname` VARCHAR(30) NOT NULL,
            `lastname` VARCHAR(30) NOT NULL,
            `birthdate` VARCHAR(10) NOT NULL,
            `gender` TINYINT NOT NULL DEFAULT 0,
            `money` LONGTEXT NULL,
            `job` LONGTEXT NULL,
            `gang` LONGTEXT NULL,
            `inventory` LONGTEXT NULL,
            `metadata` LONGTEXT NULL,
            `position` LONGTEXT NULL,
            `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
            `last_seen` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`citizenid`),
            KEY `license` (`license`)
        ) %s
    ]]):format(CHARSET))

    MySQL.query.await(([[
        CREATE TABLE IF NOT EXISTS `bigbox_items` (
            `name` VARCHAR(50) NOT NULL,
            `label` VARCHAR(60) NOT NULL,
            `weight` INT NOT NULL DEFAULT 0,
            `usable` TINYINT NOT NULL DEFAULT 0,
            `description` TEXT NULL,
            PRIMARY KEY (`name`)
        ) %s
    ]]):format(CHARSET))

    MySQL.query.await(([[
        CREATE TABLE IF NOT EXISTS `bigbox_jobs` (
            `name` VARCHAR(50) NOT NULL,
            `label` VARCHAR(60) NOT NULL,
            `type` VARCHAR(30) NOT NULL DEFAULT 'civil',
            `grades` LONGTEXT NULL,
            PRIMARY KEY (`name`)
        ) %s
    ]]):format(CHARSET))

    MySQL.query.await(([[
        CREATE TABLE IF NOT EXISTS `bigbox_gangs` (
            `name` VARCHAR(50) NOT NULL,
            `label` VARCHAR(60) NOT NULL,
            `type` VARCHAR(30) NOT NULL DEFAULT 'gang',
            `grades` LONGTEXT NULL,
            PRIMARY KEY (`name`)
        ) %s
    ]]):format(CHARSET))

    MySQL.query.await(([[
        CREATE TABLE IF NOT EXISTS `bigbox_logs` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `license` VARCHAR(60) NULL,
            `citizenid` VARCHAR(11) NULL,
            `action` VARCHAR(40) NOT NULL,
            `details` TEXT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `action` (`action`),
            KEY `created_at` (`created_at`)
        ) %s
    ]]):format(CHARSET))
end

--- Inicializa o banco. Se falhar (ex.: oxmysql ainda conectando), tenta de novo a cada 5s
--- em vez de deixar o servidor travado em silêncio.
function BB.InitDatabase()
    local attempts = 0
    while not BB.Ready do
        local ok, err = pcall(function()
            migrateLegacyTables()
            createTables()
            assert(tableExists('bigbox_players'), 'não foi possível criar/ler a tabela bigbox_players')
            assert(BB.LoadRegistry(), 'não foi possível carregar itens/empregos/gangues')
        end)
        if ok then
            BB.Ready = true
            print('^2[bigbox]^7 Banco de dados pronto e registros carregados.')
        else
            attempts = attempts + 1
            print(('^1[bigbox]^7 Falha ao iniciar o banco (tentativa %d): %s'):format(attempts, tostring(err)))
            print('^1[bigbox]^7 Confira a conexão do oxmysql (mysql_connection_string no server.cfg). Tentando de novo em 5s...')
            Wait(5000)
        end
    end
end

--- Espera o banco ficar pronto. Retorna false se passar do tempo limite.
function BB.WaitReady(timeoutMs)
    local limit = GetGameTimer() + (timeoutMs or 30000)
    while not BB.Ready do
        if GetGameTimer() > limit then return false end
        Wait(100)
    end
    return true
end

-- ============================================================
-- BigBox | server/registry.lua
-- Junta a config (arquivos) com as edições feitas no jogo (banco).
-- Regra: o que está no banco SOBRESCREVE a config.
-- Excluir do banco faz voltar ao valor da config.
-- Itens/empregos que só existem na config NÃO podem ser excluídos pelo painel.
-- ============================================================

-- grades (mapa nível -> dados) <-> lista serializável
local function gradesFromList(list)
    local out = {}
    for _, g in pairs(list or {}) do
        local level = tonumber(g.grade)
        if level then
            out[level] = { name = g.name, payment = tonumber(g.payment) or 0, boss = g.boss and true or false }
        end
    end
    return out
end

local function gradesToList(map)
    local list = {}
    for level, g in pairs(map or {}) do
        list[#list + 1] = { grade = level, name = g.name, payment = g.payment or 0, boss = g.boss and true or false }
    end
    table.sort(list, function(a, b) return a.grade < b.grade end)
    return list
end

--- Versão serializável (para enviar ao cliente) de um grupo.
function BB.SerializeGroup(g)
    return { label = g.label, type = g.type, grades = gradesToList(g.grades) }
end

local function mergeGroups(rows, target, sources)
    for _, r in ipairs(rows) do
        sources[r.name] = target[r.name] and 'override' or 'db'
        target[r.name] = {
            label = r.label,
            type = r.type,
            grades = gradesFromList(BB.SafeDecode(r.grades, {})),
        }
    end
end

local loadSeq, appliedSeq = 0, 0

--- Recarrega itens/empregos/gangues.
--- Monta TUDO em tabelas locais e só troca as globais no final, de uma vez.
--- (Antes, as globais eram zeradas no começo e jogadores que logavam durante a
--- consulta ao banco podiam cair no emprego padrão e ter isso salvo.)
---@return boolean
function BB.LoadRegistry()
    loadSeq = loadSeq + 1
    local mine = loadSeq

    local itemRows = MySQL.query.await('SELECT * FROM bigbox_items')
    local jobRows = MySQL.query.await('SELECT * FROM bigbox_jobs')
    local gangRows = MySQL.query.await('SELECT * FROM bigbox_gangs')
    if itemRows == nil or jobRows == nil or gangRows == nil then
        print('^1[bigbox]^7 Falha ao ler itens/empregos/gangues do banco; mantendo os dados atuais.')
        return false
    end

    local items = BB.Copy(Config.Items)
    local jobs = BB.Copy(Config.Jobs)
    local gangs = BB.Copy(Config.Gangs)
    local sources = { items = {}, jobs = {}, gangs = {} }
    for n in pairs(items) do sources.items[n] = 'config' end
    for n in pairs(jobs) do sources.jobs[n] = 'config' end
    for n in pairs(gangs) do sources.gangs[n] = 'config' end

    for _, r in ipairs(itemRows) do
        sources.items[r.name] = items[r.name] and 'override' or 'db'
        items[r.name] = {
            label = r.label,
            weight = r.weight,
            usable = r.usable == 1,
            description = r.description or '',
        }
    end
    mergeGroups(jobRows, jobs, sources.jobs)
    mergeGroups(gangRows, gangs, sources.gangs)

    -- Garante que o padrão exista, senão o servidor quebra.
    if not jobs[Config.DefaultJob] then
        jobs[Config.DefaultJob] = { label = BB.T('default_job'), type = 'civil', grades = { [0] = { name = BB.T('default_job_grade'), payment = 0 } } }
        sources.jobs[Config.DefaultJob] = 'config'
    end
    if not gangs[Config.DefaultGang] then
        gangs[Config.DefaultGang] = { label = BB.T('default_gang'), type = 'none', grades = { [0] = { name = BB.T('default_gang_grade'), payment = 0 } } }
        sources.gangs[Config.DefaultGang] = 'config'
    end

    -- Uma recarga mais antiga que terminou depois de uma mais nova não pode sobrescrevê-la.
    if mine < appliedSeq then return true end
    appliedSeq = mine

    BB.Items, BB.Jobs, BB.Gangs, BB.Sources = items, jobs, gangs, sources
    TriggerEvent('bigbox:server:registryReloaded')
    return true
end

-- ---------------- Salvar / excluir (usado pelo painel admin) ----------------

local function afterWrite(res)
    if res == nil then return false end
    BB.LoadRegistry()
    BB.RefreshAllPlayers()
    return true
end

function BB.SaveItem(name, data)
    return afterWrite(MySQL.update.await(
        'INSERT INTO bigbox_items (name, label, weight, usable, description) VALUES (?, ?, ?, ?, ?) ' ..
        'ON DUPLICATE KEY UPDATE label = VALUES(label), weight = VALUES(weight), usable = VALUES(usable), description = VALUES(description)',
        { name, data.label, data.weight, data.usable and 1 or 0, data.description or '' }))
end

function BB.DeleteItem(name)
    return afterWrite(MySQL.update.await('DELETE FROM bigbox_items WHERE name = ?', { name }))
end

local function tableFor(kind) return kind == 'gang' and 'bigbox_gangs' or 'bigbox_jobs' end

function BB.SaveGroup(kind, name, data)
    return afterWrite(MySQL.update.await(
        ('INSERT INTO %s (name, label, type, grades) VALUES (?, ?, ?, ?) ' ..
         'ON DUPLICATE KEY UPDATE label = VALUES(label), type = VALUES(type), grades = VALUES(grades)'):format(tableFor(kind)),
        { name, data.label, data.type, json.encode(data.grades) }))
end

function BB.DeleteGroup(kind, name)
    return afterWrite(MySQL.update.await(('DELETE FROM %s WHERE name = ?'):format(tableFor(kind)), { name }))
end

-- ============================================================
-- BigBox | server/drops.lua
-- "Chão": itens largados no mapa. Ficam só em memória (somem ao reiniciar
-- o resource) e expiram sozinhos (Config.Drops.lifetime).
-- Tudo (distância, posse, peso, espaço) é checado aqui no servidor.
-- ============================================================

BB.Drops = {}   -- [id] = { id, x, y, z, items = { nome = qtd }, created }
local nextId = 0

local function distance(c, d)
    return math.sqrt((c.x - d.x) ^ 2 + (c.y - d.y) ^ 2 + (c.z - d.z) ^ 2)
end

local function coordsOf(src)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return nil end
    return GetEntityCoords(ped)
end

local function nearestDrop(c, maxDist)
    local best, bestDist
    for _, d in pairs(BB.Drops) do
        local dist = distance(c, d)
        if dist <= maxDist and (not bestDist or dist < bestDist) then best, bestDist = d, dist end
    end
    return best
end

local function countDrops()
    local n = 0
    for _ in pairs(BB.Drops) do n = n + 1 end
    return n
end

--- Versão para o cliente (lista com rótulo, peso etc.).
local function publicDrop(d)
    local list = {}
    for name, count in pairs(d.items) do
        local def = BB.Items[name] or { label = name, weight = 0, description = '' }
        list[#list + 1] = {
            name = name, label = def.label, count = count,
            weight = def.weight or 0, description = def.description or '',
        }
    end
    table.sort(list, function(a, b) return a.label < b.label end)
    return { id = d.id, items = list }
end

local function removeDrop(id)
    BB.Drops[id] = nil
    TriggerClientEvent('bigbox:client:dropUpdate', -1, id, nil)
end

-- ---------------- Callbacks ----------------

lib.callback.register('bigbox:drop:getNearby', function(src)
    if not BB.GetPlayer(src) then return nil end
    local c = coordsOf(src)
    local d = c and nearestDrop(c, Config.Drops.distance)
    return d and publicDrop(d) or nil
end)

lib.callback.register('bigbox:dropItem', function(src, name, count)
    local p = BB.GetPlayer(src)
    count = BB.ToInt(count)
    if not p or type(name) ~= 'string' or not count or count <= 0 then return false, 'invalid_amount' end
    if not BB.RateLimit(src, 'drop', 400) then return false, 'rate_limited' end
    if not p:HasItem(name, count) then return false, 'item_not_found' end

    local c = coordsOf(src)
    if not c then return false, 'too_far' end

    local d = nearestDrop(c, Config.Drops.distance)
    local isNew = d == nil
    if isNew then
        if countDrops() >= Config.Drops.maxDrops then return false, 'drop_limit' end
        nextId = nextId + 1
        d = { id = nextId, x = c.x, y = c.y, z = c.z, items = {}, created = os.time() }
        BB.Drops[d.id] = d
    end

    p:RemoveItem(name, count, true)
    d.items[name] = (d.items[name] or 0) + count
    d.created = os.time()

    if isNew then TriggerClientEvent('bigbox:client:dropUpdate', -1, d.id, { x = d.x, y = d.y, z = d.z }) end
    BB.Log(src, 'item:drop', { item = name, count = count })
    return true, publicDrop(d)
end)

lib.callback.register('bigbox:pickupItem', function(src, dropId, name, count)
    local p = BB.GetPlayer(src)
    dropId, count = BB.ToInt(dropId), BB.ToInt(count)
    if not p or not dropId or type(name) ~= 'string' or not count or count <= 0 then return false, 'invalid_amount' end
    if not BB.RateLimit(src, 'pickup', 300) then return false, 'rate_limited' end

    local d = BB.Drops[dropId]
    if not d or (d.items[name] or 0) < count then return false, 'item_not_found' end
    local c = coordsOf(src)
    if not c or distance(c, d) > Config.Drops.distance + 1.5 then return false, 'too_far' end

    -- AddItem confere peso e espaço. Sem pausas entre adicionar e tirar do chão: não duplica.
    local ok, err = p:AddItem(name, count)
    if not ok then return false, err end

    d.items[name] = d.items[name] - count
    if d.items[name] <= 0 then d.items[name] = nil end
    BB.Log(src, 'item:pickup', { item = name, count = count })

    if next(d.items) == nil then
        removeDrop(d.id)
        return true, nil
    end
    return true, publicDrop(d)
end)

-- ---------------- Sincronização ----------------

--- Quem entra no jogo recebe a lista das pilhas existentes.
AddEventHandler('bigbox:server:playerLoaded', function(src)
    local list = {}
    for id, d in pairs(BB.Drops) do list[#list + 1] = { id = id, x = d.x, y = d.y, z = d.z } end
    TriggerClientEvent('bigbox:client:dropSync', src, list)
end)

-- Pilhas antigas expiram
CreateThread(function()
    while true do
        Wait(60000)
        local limit = os.time() - (Config.Drops.lifetime or 30) * 60
        for id, d in pairs(BB.Drops) do
            if d.created < limit then removeDrop(id) end
        end
    end
end)

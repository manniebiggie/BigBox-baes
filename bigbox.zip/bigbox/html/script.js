// BigBox Inventory — interface (NUI). Só pede ações ao Lua; o servidor decide tudo.
'use strict';

const RES = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'bigbox';
const $ = (sel) => document.querySelector(sel);

const post = (name, data = {}) =>
    fetch(`https://${RES}/${name}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify(data),
    }).catch(() => {});

const state = {
    items: [],        // itens do jogador (cada um com .slot)
    slots: 25,
    ground: null,     // { id, items: [...] } ou null
    cfg: {},
    drag: null,       // { zone: 'player' | 'ground', name, count }
    menuItem: null,   // item do menu de contexto
};

// ---------- utilidades ----------

const el = (tag, cls, text) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
};

const kg = (g) => ((g || 0) / 1000).toFixed(2);

/** Quantidade do campo "Quantidade": 0 (ou maior que a pilha) = tudo. */
function wantedAmount(count) {
    const n = parseInt($('#amount').value, 10) || 0;
    return n <= 0 || n > count ? count : n;
}

function applyTranslations(ui) {
    document.querySelectorAll('[data-t]').forEach((node) => {
        const text = ui[node.dataset.t];
        if (text) node.textContent = text;
    });
}

// ---------- tooltip ----------

const tip = $('#tooltip');

function showTip(item, e) {
    tip.replaceChildren();
    tip.append(el('b', '', item.label));
    if (item.description) tip.append(el('span', '', item.description));
    tip.append(el('small', '', `${state.ui.weight || 'Peso'}: ${kg(item.weight * item.count)} kg`));
    tip.classList.remove('hidden');
    moveTip(e);
}
function moveTip(e) {
    const w = tip.offsetWidth, h = tip.offsetHeight;
    tip.style.left = Math.min(e.clientX + 16, window.innerWidth - w - 8) + 'px';
    tip.style.top = Math.min(e.clientY + 16, window.innerHeight - h - 8) + 'px';
}
const hideTip = () => tip.classList.add('hidden');

// ---------- slots ----------

function makeSlot(item, zone, slotNumber) {
    const slot = el('div', 'slot');
    if (zone === 'player') slot.dataset.slot = slotNumber;
    if (zone === 'player' && slotNumber <= 5) slot.append(el('span', 'num', slotNumber));
    if (!item) return slot;

    slot.classList.add('filled');
    slot.draggable = true;
    slot.append(el('span', 'qty', item.count));

    const fallback = el('div', 'fallback', item.label);
    const img = new Image();
    img.src = `${state.cfg.imagePath || ''}${item.name}.png`;
    img.onload = () => fallback.remove();
    img.onerror = () => img.remove();
    slot.append(img, fallback);

    slot.addEventListener('dragstart', (e) => {
        state.drag = { zone, name: item.name, count: item.count };
        slot.classList.add('dragging');
        hideTip(); hideMenu();
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', item.name);
    });
    slot.addEventListener('dragend', () => {
        state.drag = null;
        document.querySelectorAll('.dragging, .over').forEach((n) => n.classList.remove('dragging', 'over'));
    });
    slot.addEventListener('mouseenter', (e) => showTip(item, e));
    slot.addEventListener('mousemove', moveTip);
    slot.addEventListener('mouseleave', hideTip);

    if (zone === 'player') {
        slot.addEventListener('contextmenu', (e) => { e.preventDefault(); showMenu(item, e); });
        slot.addEventListener('dblclick', () => { if (item.usable) post('use', { name: item.name }); });
    } else {
        slot.addEventListener('dblclick', () => post('pickup', { name: item.name, amount: wantedAmount(item.count) }));
    }
    return slot;
}

function renderPlayer() {
    const grid = $('#grid');
    grid.replaceChildren();
    const bySlot = new Map(state.items.map((it) => [it.slot, it]));
    for (let i = 1; i <= state.slots; i++) {
        const slot = makeSlot(bySlot.get(i), 'player', i);
        // alvo de soltar: mover/trocar de lugar, ou pegar do chão
        slot.addEventListener('dragover', (e) => { if (state.drag) { e.preventDefault(); slot.classList.add('over'); } });
        slot.addEventListener('dragleave', () => slot.classList.remove('over'));
        slot.addEventListener('drop', (e) => {
            e.preventDefault();
            slot.classList.remove('over');
            const d = state.drag;
            if (!d) return;
            if (d.zone === 'player') post('move', { name: d.name, slot: i });
            else post('pickup', { name: d.name, amount: wantedAmount(d.count) });
        });
        grid.append(slot);
    }
}

function renderGround() {
    const grid = $('#ground');
    grid.replaceChildren();
    const items = (state.ground && state.ground.items) || [];
    items.forEach((it) => grid.append(makeSlot(it, 'ground')));
    for (let i = items.length; i < 15; i++) grid.append(makeSlot(null, 'ground'));
    $('#ground-empty').classList.toggle('hidden', items.length > 0);
    $('#ground-info').textContent = items.length ? `${items.length}` : '';
}

// o painel inteiro do chão aceita itens soltos (largar no chão)
const rightPanel = $('#right');
rightPanel.addEventListener('dragover', (e) => {
    if (state.drag && state.drag.zone === 'player') { e.preventDefault(); rightPanel.classList.add('over'); }
});
rightPanel.addEventListener('dragleave', (e) => { if (!rightPanel.contains(e.relatedTarget)) rightPanel.classList.remove('over'); });
rightPanel.addEventListener('drop', (e) => {
    e.preventDefault();
    rightPanel.classList.remove('over');
    const d = state.drag;
    if (d && d.zone === 'player') post('drop', { name: d.name, amount: wantedAmount(d.count) });
});

// ---------- menu de contexto ----------

const menu = $('#menu');
const range = $('#menu-range');

function showMenu(item, e) {
    state.menuItem = item;
    hideTip();
    $('#menu-title').textContent = item.label;
    range.max = item.count;
    range.value = Math.min(wantedAmount(item.count), item.count);
    $('#menu-count').textContent = range.value;
    menu.querySelector('[data-act="use"]').classList.toggle('hidden', !item.usable);
    menu.classList.remove('hidden');
    const w = menu.offsetWidth, h = menu.offsetHeight;
    menu.style.left = Math.max(8, Math.min(e.clientX, window.innerWidth - w - 8)) + 'px';
    menu.style.top = Math.max(8, Math.min(e.clientY, window.innerHeight - h - 8)) + 'px';
}
function hideMenu() { menu.classList.add('hidden'); state.menuItem = null; }

range.addEventListener('input', () => { $('#menu-count').textContent = range.value; });
menu.addEventListener('click', (e) => {
    const act = e.target.dataset && e.target.dataset.act;
    const item = state.menuItem;
    if (!act || !item) return;
    const amount = parseInt(range.value, 10) || 1;
    if (act === 'use') post('use', { name: item.name });
    else post(act, { name: item.name, amount });   // 'give' ou 'drop'
    hideMenu();
});
document.addEventListener('mousedown', (e) => { if (!menu.contains(e.target)) hideMenu(); });
document.addEventListener('contextmenu', (e) => e.preventDefault());

// ---------- dados do jogador ----------

function setVitals(v) {
    if (!v) return;
    document.querySelectorAll('.vital').forEach((row) => {
        const key = row.dataset.k;
        const val = Math.max(0, Math.min(100, Math.round(v[key] ?? 0)));
        row.querySelector('i').style.width = val + '%';
        row.querySelector('b').textContent = val;
        row.classList.toggle('low', val <= 25);
    });
}

function setData(d) {
    state.items = d.items || [];
    state.slots = d.slots || 25;
    state.ground = d.ground || null;

    $('#weight').textContent = `${kg(d.weight)}kg/${kg(d.maxWeight)}kg`;
    $('#p-name').textContent = d.name || '-';
    $('#p-cid').textContent = d.citizenid || '-';
    $('#p-job').textContent = d.job || '-';

    const money = $('#p-money');
    money.replaceChildren();
    (d.money || []).forEach((m) => {
        const line = el('div', 'money-line');
        line.append(el('small', '', m.label), el('span', '', '$' + m.amount));
        money.append(line);
    });

    if (state.menuItem && !state.items.some((it) => it.name === state.menuItem.name)) hideMenu();
    renderPlayer();
    renderGround();
    setVitals(d.vitals);
}

// ---------- mensagens do Lua ----------

window.addEventListener('message', (e) => {
    const { action, data } = e.data || {};
    if (action === 'open') {
        state.cfg = e.data.config || {};
        state.ui = e.data.ui || {};
        applyTranslations(state.ui);
        $('#silhouette').classList.toggle('hidden', !!state.cfg.preview);
        $('#app').classList.remove('hidden');
        setData(data);
    } else if (action === 'update') {
        setData(data);
    } else if (action === 'vitals') {
        setVitals(data);
    } else if (action === 'close') {
        $('#app').classList.add('hidden');
        hideMenu(); hideTip();
    }
});

// ---------- fechar ----------

$('#close').addEventListener('click', () => post('close'));
document.addEventListener('keydown', (e) => {
    if ($('#app').classList.contains('hidden')) return;
    if (e.key === 'Escape') {
        if (!menu.classList.contains('hidden')) hideMenu(); else post('close');
    } else if (e.key === 'Tab') {
        e.preventDefault();
        post('close');
    } else if (state.cfg.closeKey && e.key.toUpperCase() === String(state.cfg.closeKey).toUpperCase()
               && document.activeElement !== $('#amount')) {
        post('close');
    }
});

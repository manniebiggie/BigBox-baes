# BigBox — base FiveM feita para editar fácil

Framework em Lua (**ox_lib + oxmysql**): personagens, dinheiro, inventário com interface própria
(slots, arrastar e soltar, chão), empregos, gangues, salário, morte/hospital, logs e painel admin no jogo.
Evolução do BQBox: mesmos conceitos, com correções, testes e inventário novo.

> ⚠️ **Teste num servidor de desenvolvimento antes de produção.** A lógica de servidor (38 testes) e da
> interface (testes com DOM simulado) foi validada fora do jogo, mas **nunca rodou dentro do FiveM**.
> O ponto mais sensível é o **personagem 3D** do inventário (veja "Inventário"). Mande os erros do console.

## Instalação
1. Instale `ox_lib` e `oxmysql` (configure a conexão no `server.cfg`).
2. Coloque `bigbox` (e, se quiser, `bigbox_bridge`) em `resources/`:
   ```
   ensure ox_lib
   ensure oxmysql
   ensure bigbox
   add_principal identifier.license:SUA_LICENSE group.admin
   ```
3. As tabelas (`bigbox_players`, `_items`, `_jobs`, `_gangs`, `_logs`) são criadas sozinhas, em **utf8mb4** (acentos ok).
4. **Vindo do BQBox?** Pare e remova o `bqbox`. Na 1ª subida o BigBox renomeia `bqbox_*` → `bigbox_*`
   **sem perder dados**. Scripts que usavam `exports.bqbox` continuam funcionando (`provide 'bqbox'` no manifest).
   Eventos e comandos mudaram de nome: `bqbox:...` → `bigbox:...` e `/bqadmin` → `/bigadmin`.
5. Remova `spawnmanager`, `mapmanager` e `basic-gamemode` do `server.cfg` se existirem (o BigBox controla o spawn).

## Onde editar (sem mexer em código)
| O quê | Arquivo |
|---|---|
| Nome, spawn, dinheiro, salário, teclas, slots, morte, chão, logs | `config/main.lua` |
| Itens | `config/items.lua` |
| Empregos e gangues | `config/jobs.lua` |
| Todos os textos | `locales/pt-br.lua` / `en.lua` |
| Ações de itens usáveis | `server/items.lua` |
| Comandos | `server/commands.lua` |
| Cores/tamanhos do inventário | `html/style.css` (variáveis no topo) |

**Painel in-game:** `/bigadmin` — jogadores online (emprego, gangue, dinheiro, itens, reanimar, trocar de personagem),
e criar/editar/excluir itens, empregos, gangues e cargos. Edições ficam no banco e **sobrescrevem** a config.
Cada registro mostra a origem (arquivo / painel / arquivo + painel); o que só existe no arquivo não pode ser
excluído pelo painel (apague no arquivo).

## Inventário (NUI)
Tecla **F2** (ou `/inventario`). Três áreas, como na referência:
- **Corpo:** o **seu personagem em 3D** (roupas e aparência reais) + barras de **saúde, colete, fome e sede** em tempo real, e seus dados.
- **Jogador:** slots; **arraste** para mover/trocar de lugar; **clique direito** = Usar / Entregar / Largar com controle de quantidade;
  duplo clique usa. Slots 1-5 são atalhos: as teclas **1-5** usam o item do slot.
- **Chão:** arraste um item para lá para **largar** (aparece um saquinho no mapa); arraste do chão para o seu inventário (ou duplo clique) para **pegar**.
  Pilhas expiram em 30 min e somem ao reiniciar o resource.

O campo **Quantidade** vale para arrastar (0 = tudo). Tudo (peso, espaço, distância, posse) é validado no **servidor**.

**Ícones:** coloque `nome_do_item.png` em `html/images/`, ou aponte `Config.Inventory.ImagePath` para a pasta
de outro inventário (ex.: `'nui://qb-inventory/html/images/'`). Sem imagem aparece o nome do item.

**Personagem 3D — como funciona e se der problema:** um clone do seu ped é entregue ao menu de pausa do GTA,
que o desenha com fundo transparente; a NUI fica por cima. É a técnica usada por vários inventários, mas
depende de comportamento do jogo que não pude testar. Se ficar invisível, no lugar errado ou conflitar com outro script:
`Config.Inventory.Preview = false` (mostra uma silhueta) e me avise. Ajuste o escurecimento atrás do personagem em
`--dim-left` no `html/style.css`.

## Comandos
Admin: `/setjob id job [grade]`, `/setgang id gang [grade]`, `/givemoney`, `/removemoney`, `/setmoney id tipo valor`,
`/giveitem`, `/removeitem id item [qtd]`, `/revive [id]`, `/bigadmin`
Jogador: `/duty`, `/trocarchar`, `/inventario` (F2), teclas 1-5.
Admin = ACE `Config.AdminAce` (`group.admin`) ou quem tem `add_ace group.admin command allow`.

## API para outros scripts (exports do servidor)
```lua
exports.bigbox:GetPlayerData(source)
exports.bigbox:AddMoney(source, 'cash', 100, 'motivo' [, silent])
exports.bigbox:RemoveMoney(source, 'bank', 50, 'motivo')
exports.bigbox:AddItem(source, 'water', 2 [, silent])    -- retorna false, 'too_heavy' | 'inv_full' | 'invalid_item'
exports.bigbox:RemoveItem(source, 'water', 1)
exports.bigbox:CanCarry(source, 'water', 2)
exports.bigbox:SetJob(source, 'police', 2)               -- grade omitida = menor cargo
exports.bigbox:RegisterUsable('water', function(source) ... end)  -- some sozinho se o seu resource parar
exports.bigbox:IsAdmin(source)   exports.bigbox:Log(source, 'acao', 'detalhes')
```
Eventos: `bigbox:server:playerLoaded`, `playerUnloaded`, `moneyChange`, `itemChange`, `jobUpdated`, `gangUpdated`,
`dutyChange`, `deathChange`, `registryReloaded`. Cliente: `bigbox:client:playerLoaded` (gancho para o criador de aparência),
`exports.bigbox:GetPlayerData()`, `IsSpawned()`, `IsDead()`, `IsInventoryOpen()`.

## O que mudou em relação ao BQBox
**Bugs corrigidos**
- *Perda de dados:* ao recarregar itens/empregos, o registro era zerado e só depois relido do banco; quem logava nesse intervalo
  caía no emprego padrão **e isso era salvo**. Agora a troca é atômica (e recargas antigas não sobrescrevem as novas).
- *Personagem herdado:* se o jogador caísse enquanto o personagem carregava, ficava um "fantasma" em memória e o próximo
  jogador com o mesmo ID herdava o personagem. Corrigido.
- *Acentos:* tabelas sem `utf8mb4` quebravam nomes como "José" em alguns bancos.
- *Validação:* datas impossíveis (31/02), futuras ou sem limite de idade; nomes com emoji, quebras de linha e texto UTF-8 inválido; criar vários personagens ao mesmo tempo burlava o limite.
- *Números:* `NaN`/infinito/decimais em dinheiro e itens; sem teto de dinheiro.
- `/setjob` sem cargo forçava o nível 0 e falhava em empregos que começam em 1.
- Painel: excluir item/emprego do arquivo parecia funcionar mas não fazia nada; edição de cargo com nível repetido duplicava.
- `RegisterUsable` de outro resource continuava registrado (e dava erro) depois de o resource parar.
- Usar item sem ação falhava em silêncio; erro dentro da ação derrubava o callback.
- Banco fora do ar travava o servidor em silêncio; agora avisa e tenta de novo.
- Textos fixos em português no código e na ponte (README dizia que não havia).
- Ponte: `QBCore.Shared` ficava desatualizado após edições do painel (cliente e servidor).
- Salvamento automático bloqueava o servidor com muitos jogadores (agora assíncrono).

**Novidades:** inventário NUI com slots/chão/saúde/personagem 3D, dar item a quem está perto, morte e hospital, vida/colete salvos,
logs no banco, antispam nos callbacks, jogadores online no painel, excluir personagem (opcional), migração automática de tabelas,
`/removemoney /setmoney /removeitem /revive`.

## Limitações atuais
- Sem criador de aparência (use o gancho `bigbox:client:playerLoaded`, ex.: illenium-appearance).
- Sem HUD, fome/sede automáticas, garagem, lojas etc. (fome/sede existem só como valores em `metadata`).
- Itens sem metadados por unidade (uma pilha por item); armas/durabilidade pedem um inventário mais completo (ex.: ox_inventory).
- Itens do chão não sobrevivem a reinício. A compatibilidade com QBCore é parcial (`bigbox_bridge/README.md`).
- Se você usa outro script de morte/ambulância: `Config.Death.enabled = false`.

## Testes
Em `_testes/` (fora dos resources; não coloque em `resources/`): 38 testes de servidor + 4 da ponte (Lua com FiveM
simulado, rodam com `texlua`/Lua 5.3+) e testes da interface (`node ui_test.js`, DOM simulado). Isso **não substitui** testar no jogo.

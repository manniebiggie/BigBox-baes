-- ============================================================
-- BigBox | config/jobs.lua
-- Empregos e gangues. grades = cargos (nível 0 é o mais baixo).
-- payment = salário por ciclo, boss = true dá acesso a funções de chefe.
-- type: texto livre para seus scripts filtrarem (ex.: 'leo', 'ems', 'civil').
-- Também editável no jogo via /bigadmin.
-- ============================================================

Config.Jobs = {
    unemployed = {
        label = 'Desempregado',
        type = 'civil',
        grades = {
            [0] = { name = 'Autônomo', payment = 10 },
        },
    },
    police = {
        label = 'Polícia',
        type = 'leo',
        grades = {
            [0] = { name = 'Recruta',    payment = 50 },
            [1] = { name = 'Oficial',    payment = 75 },
            [2] = { name = 'Sargento',   payment = 100 },
            [3] = { name = 'Comandante', payment = 150, boss = true },
        },
    },
    ambulance = {
        label = 'Paramédico',
        type = 'ems',
        grades = {
            [0] = { name = 'Estagiário', payment = 50 },
            [1] = { name = 'Médico',     payment = 90 },
            [2] = { name = 'Diretor',    payment = 140, boss = true },
        },
    },
}

Config.Gangs = {
    none = {
        label = 'Sem gangue',
        type = 'none',
        grades = {
            [0] = { name = 'Nenhum', payment = 0 },
        },
    },
}

-- ============================================================
-- BigBox | config/items.lua
-- Para criar um item: copie uma linha e mude o nome (minúsculas, sem espaço).
-- weight em gramas. usable = true permite usar pelo inventário
-- (a ação do item é registrada em server/items.lua).
-- Itens também podem ser criados/editados no jogo via /bigadmin.
-- ============================================================

Config.Items = {
    water   = { label = 'Água',      weight = 500, usable = true,  description = 'Garrafa de água mineral.' },
    bread   = { label = 'Pão',       weight = 300, usable = true,  description = 'Pãozinho fresco.' },
    phone   = { label = 'Celular',   weight = 200, usable = false, description = 'Um smartphone.' },
    id_card = { label = 'Documento', weight = 50,  usable = false, description = 'Documento de identidade.' },
}

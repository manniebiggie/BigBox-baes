-- ============================================================
-- BigBox | config/main.lua
-- Configurações gerais. Tudo aqui pode ser editado sem tocar no código.
-- ============================================================

Config.Locale = 'pt-br'              -- 'pt-br' ou 'en' (veja a pasta locales/)
Config.ServerName = 'Meu Servidor'
Config.Debug = false

-- Quem pode usar comandos e o painel admin (permissão ACE).
-- No server.cfg:
--   add_principal identifier.license:SEULICENSE group.admin
-- Quem tiver `add_ace group.admin command allow` também é aceito como admin.
Config.AdminAce = 'group.admin'

-- ---------------- Personagens ----------------
Config.MaxCharacters = 3
Config.AllowDeleteCharacter = false  -- true mostra a opção "Excluir" no menu de personagens
Config.MinAge = 16                   -- idade mínima do personagem (anos)
Config.MaxAge = 100                  -- idade máxima
Config.DefaultSpawn = vec4(-269.4, -955.3, 31.2, 205.8)
Config.SpawnProtection = 3           -- segundos de invencibilidade ao entrar (0 desliga)

-- ---------------- Dinheiro ----------------
-- Para criar um novo tipo de dinheiro, basta adicionar uma linha aqui.
Config.Money = {
    cash = { label = 'Dinheiro', start = 500 },
    bank = { label = 'Banco',    start = 5000 },
}
Config.MaxMoney = 2000000000         -- teto por tipo de dinheiro (evita estouro de número)

-- ---------------- Emprego / Gangue padrão ----------------
Config.DefaultJob = 'unemployed'
Config.DefaultJobGrade = 0
Config.DefaultGang = 'none'
Config.DefaultGangGrade = 0

-- ---------------- Inventário ----------------
Config.Inventory = {
    MaxWeight = 30000,               -- em gramas (30 kg)
    Slots = 25,                      -- espaços (os 5 primeiros são os atalhos 1-5)
    GiveDistance = 3.0,              -- distância máxima para entregar item a outro jogador
    Preview = true,                  -- mostra o SEU personagem em 3D no painel (false = silhueta simples)
    ImagePath = 'nui://bigbox/html/images/', -- ícones dos itens: <ImagePath><nome_do_item>.png
}

-- ---------------- Chão (itens largados) ----------------
Config.Drops = {
    distance = 2.5,                  -- raio para ver/pegar itens do chão
    lifetime = 30,                   -- minutos até a pilha sumir
    maxDrops = 150,                  -- limite de pilhas no mapa
    prop = 'prop_paper_bag_01',      -- objeto mostrado no chão
}

-- ---------------- Salário ----------------
Config.Paycheck = {
    enabled = true,
    interval = 15,                   -- minutos
    account = 'bank',                -- tipo de dinheiro que recebe
}

-- ---------------- Salvamento automático ----------------
Config.SaveInterval = 5              -- minutos

-- ---------------- Morte / Hospital ----------------
Config.Death = {
    enabled = true,                  -- false = você usa outro script de morte/ambulância
    respawnTime = 60,                -- segundos até poder renascer
    fee = 500,                       -- taxa cobrada pelo hospital (0 = grátis)
    account = 'bank',                -- de onde cobrar a taxa
    -- Hospitais: o mais próximo de onde o jogador morreu é usado.
    hospitals = {
        vec4(308.2, -595.0, 43.3, 70.0),
    },
}

-- ---------------- Teclas ----------------
Config.Keys = {
    inventory = 'F2',
    hotbar = true,                   -- teclas 1-5 usam o item do atalho correspondente
    respawn = 38,                    -- controle do GTA (38 = E) usado para renascer
}

-- ---------------- Notificações ----------------
Config.Notify = {
    position = 'top-right',
    duration = 5000,
    money = true,                    -- avisar quando ganhar/perder dinheiro
    items = true,                    -- avisar quando ganhar/perder itens
}

-- ---------------- Logs ----------------
Config.Logs = {
    console = true,                  -- mostra ações admin no console do servidor
    database = true,                 -- grava ações importantes na tabela bigbox_logs
    moneyThreshold = 50000,          -- movimentações de dinheiro >= este valor são registradas
}
